"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ArrowRight, Download, TrendingUp, TrendingDown } from "lucide-react"

interface StatData {
  year: number
  value: number
  percentage: number
}

interface PortfolioMetric {
  title: string
  unit: string
  currentValue: string
  changeFromBaseline: number
  isPositive: boolean
  baselineYear: number
  data: StatData[]
  actionText: string
  hasDownload: boolean
}

const portfolioData: PortfolioMetric[] = [
  {
    title: "Managed portfolio carbon footprint",
    unit: "tCO₂e",
    currentValue: "45,048",
    changeFromBaseline: 16,
    isPositive: false,
    baselineYear: 2019,
    data: [
      { year: 2022, value: 45048, percentage: 100 },
      { year: 2021, value: 14111, percentage: 31 },
      { year: 2020, value: 32813, percentage: 73 },
      { year: 2019, value: 38673, percentage: 86 },
    ],
    actionText: "See full breakdown of carbon footprint",
    hasDownload: false,
  },
  {
    title: "Managed portfolio energy intensity",
    unit: "kWh/m²",
    currentValue: "123",
    changeFromBaseline: -22,
    isPositive: true,
    baselineYear: 2019,
    data: [
      { year: 2022, value: 123, percentage: 78 },
      { year: 2021, value: 128, percentage: 82 },
      { year: 2020, value: 135, percentage: 86 },
      { year: 2019, value: 157, percentage: 100 },
    ],
    actionText: "Download the data",
    hasDownload: true,
  },
  {
    title: "Managed portfolio energy consumption",
    unit: "kWh",
    currentValue: "47,790,662",
    changeFromBaseline: -27,
    isPositive: true,
    baselineYear: 2019,
    data: [
      { year: 2022, value: 47790662, percentage: 73 },
      { year: 2021, value: 49324077, percentage: 76 },
      { year: 2020, value: 48784205, percentage: 75 },
      { year: 2019, value: 65198706, percentage: 100 },
    ],
    actionText: "Download the data",
    hasDownload: true,
  },
]

export function PortfolioStats() {
  return (
    <div className="w-full max-w-7xl mx-auto p-6 bg-gray-50 dark:bg-gray-900">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {portfolioData.map((metric, index) => (
          <Card key={index} className="bg-white dark:bg-gray-800 border-0 shadow-sm">
            <CardContent className="p-8">
              {/* Header */}
              <div className="mb-8">
                <h3 className="text-gray-700 dark:text-gray-300 text-lg font-medium mb-2 leading-tight">
                  {metric.title}
                </h3>
                <div className="flex items-baseline gap-2">
                  <span className="text-gray-500 dark:text-gray-400 text-sm">{metric.unit}</span>
                </div>
              </div>

              {/* Main Value */}
              <div className="mb-6">
                <div className="text-4xl font-light text-gray-900 dark:text-white mb-2">{metric.currentValue}</div>
                <div className="flex items-center gap-2 text-sm">
                  <span className="text-gray-500 dark:text-gray-400">from {metric.baselineYear}</span>
                  <div className="flex items-center gap-1">
                    {metric.isPositive ? (
                      <TrendingDown className="w-4 h-4 text-green-600" />
                    ) : (
                      <TrendingUp className="w-4 h-4 text-red-600" />
                    )}
                    <span className={metric.isPositive ? "text-green-600" : "text-red-600"}>
                      {Math.abs(metric.changeFromBaseline)}%
                    </span>
                  </div>
                </div>
              </div>

              {/* Data Bars */}
              <div className="space-y-4 mb-8">
                {metric.data.map((item) => (
                  <div key={item.year} className="flex items-center gap-4">
                    <span className="text-gray-600 dark:text-gray-400 text-sm w-8">{item.year}</span>
                    <div className="flex-1 relative">
                      <div className="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-red-400 rounded-full transition-all duration-500"
                          style={{ width: `${item.percentage}%` }}
                        />
                      </div>
                    </div>
                    <span className="text-gray-600 dark:text-gray-400 text-sm w-20 text-right">
                      {item.value.toLocaleString()}
                    </span>
                  </div>
                ))}
              </div>

              {/* Action Button */}
              <Button
                variant="ghost"
                className="w-full justify-between p-0 h-auto text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white group"
              >
                <span className="text-sm">{metric.actionText}</span>
                {metric.hasDownload ? (
                  <Download className="w-4 h-4 group-hover:translate-y-0.5 transition-transform" />
                ) : (
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
                )}
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
