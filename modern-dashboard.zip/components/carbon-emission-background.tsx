"use client"

import type React from "react"
import { useEffect, useRef, useState } from "react"

interface EmissionParticle {
  id: number
  x: number
  y: number
  vx: number
  vy: number
  life: number
  maxLife: number
  type: "co2" | "reduction" | "neutral"
  size: number
}

interface CarbonEmissionBackgroundProps {
  children: React.ReactNode
  className?: string
  emissionLevel?: "high" | "medium" | "low" | "negative"
  interactive?: boolean
  particleCount?: number
}

export function CarbonEmissionBackground({
  children,
  className = "",
  emissionLevel = "medium",
  interactive = true,
  particleCount = 30,
}: CarbonEmissionBackgroundProps) {
  const containerRef = useRef<HTMLDivElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [particles, setParticles] = useState<EmissionParticle[]>([])
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 })
  const animationRef = useRef<number>()

  // Initialize particles
  useEffect(() => {
    const newParticles: EmissionParticle[] = []

    for (let i = 0; i < particleCount; i++) {
      const particleType = emissionLevel === "high" ? "co2" : emissionLevel === "negative" ? "reduction" : "neutral"

      newParticles.push({
        id: i,
        x: Math.random() * 100,
        y: Math.random() * 100,
        vx: (Math.random() - 0.5) * 0.5,
        vy: (Math.random() - 0.5) * 0.5,
        life: Math.random() * 100,
        maxLife: 100,
        type: particleType,
        size: Math.random() * 3 + 1,
      })
    }

    setParticles(newParticles)
  }, [particleCount, emissionLevel])

  // Canvas animation
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const resizeCanvas = () => {
      if (containerRef.current) {
        const rect = containerRef.current.getBoundingClientRect()
        canvas.width = rect.width
        canvas.height = rect.height
      }
    }

    resizeCanvas()
    window.addEventListener("resize", resizeCanvas)

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height)

      // Update and draw particles
      setParticles((prevParticles) => {
        return prevParticles.map((particle) => {
          // Update position
          let newX = particle.x + particle.vx
          let newY = particle.y + particle.vy

          // Wrap around edges
          if (newX < 0) newX = 100
          if (newX > 100) newX = 0
          if (newY < 0) newY = 100
          if (newY > 100) newY = 0

          // Update life
          let newLife = particle.life + 1
          if (newLife > particle.maxLife) newLife = 0

          // Interactive mouse effect
          if (interactive) {
            const particleScreenX = (newX / 100) * canvas.width
            const particleScreenY = (newY / 100) * canvas.height
            const dx = mousePos.x - particleScreenX
            const dy = mousePos.y - particleScreenY
            const distance = Math.sqrt(dx * dx + dy * dy)

            if (distance < 100) {
              const force = (100 - distance) / 100
              newX -= (dx / distance) * force * 0.5
              newY -= (dy / distance) * force * 0.5
            }
          }

          return {
            ...particle,
            x: newX,
            y: newY,
            life: newLife,
          }
        })
      })

      // Draw particles
      particles.forEach((particle) => {
        const screenX = (particle.x / 100) * canvas.width
        const screenY = (particle.y / 100) * canvas.height
        const opacity = (particle.life / particle.maxLife) * 0.6

        // Set color based on particle type
        let color: string
        switch (particle.type) {
          case "co2":
            color = `rgba(239, 68, 68, ${opacity})` // Red for emissions
            break
          case "reduction":
            color = `rgba(34, 197, 94, ${opacity})` // Green for reduction
            break
          default:
            color = `rgba(59, 130, 246, ${opacity})` // Blue for neutral
        }

        // Draw particle with glow effect
        ctx.shadowBlur = 10
        ctx.shadowColor = color
        ctx.fillStyle = color
        ctx.beginPath()
        ctx.arc(screenX, screenY, particle.size, 0, Math.PI * 2)
        ctx.fill()

        // Draw CO₂ molecule structure for emission particles
        if (particle.type === "co2" && particle.size > 2) {
          ctx.shadowBlur = 0
          ctx.fillStyle = `rgba(75, 85, 99, ${opacity * 0.8})`

          // Carbon atom (center)
          ctx.beginPath()
          ctx.arc(screenX, screenY, 2, 0, Math.PI * 2)
          ctx.fill()

          // Oxygen atoms
          ctx.beginPath()
          ctx.arc(screenX - 6, screenY, 1.5, 0, Math.PI * 2)
          ctx.fill()

          ctx.beginPath()
          ctx.arc(screenX + 6, screenY, 1.5, 0, Math.PI * 2)
          ctx.fill()

          // Bonds
          ctx.strokeStyle = `rgba(75, 85, 99, ${opacity * 0.6})`
          ctx.lineWidth = 1
          ctx.beginPath()
          ctx.moveTo(screenX - 2, screenY)
          ctx.lineTo(screenX - 4, screenY)
          ctx.moveTo(screenX + 2, screenY)
          ctx.lineTo(screenX + 4, screenY)
          ctx.stroke()
        }

        // Draw reduction arrows for reduction particles
        if (particle.type === "reduction" && particle.size > 2) {
          ctx.shadowBlur = 0
          ctx.strokeStyle = `rgba(34, 197, 94, ${opacity})`
          ctx.lineWidth = 2
          ctx.beginPath()
          ctx.moveTo(screenX - 4, screenY + 2)
          ctx.lineTo(screenX, screenY - 2)
          ctx.lineTo(screenX + 4, screenY + 2)
          ctx.stroke()
        }
      })

      ctx.shadowBlur = 0

      animationRef.current = requestAnimationFrame(animate)
    }

    animate()

    return () => {
      window.removeEventListener("resize", resizeCanvas)
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current)
      }
    }
  }, [particles, mousePos, interactive])

  const handleMouseMove = (event: React.MouseEvent) => {
    if (!interactive || !canvasRef.current) return

    const rect = canvasRef.current.getBoundingClientRect()
    setMousePos({
      x: event.clientX - rect.left,
      y: event.clientY - rect.top,
    })
  }

  const getBackgroundGradient = () => {
    switch (emissionLevel) {
      case "high":
        return "from-red-900/20 via-orange-900/10 to-transparent"
      case "medium":
        return "from-yellow-900/20 via-orange-900/10 to-transparent"
      case "low":
        return "from-green-900/20 via-blue-900/10 to-transparent"
      case "negative":
        return "from-emerald-900/20 via-green-900/10 to-transparent"
      default:
        return "from-blue-900/20 via-purple-900/10 to-transparent"
    }
  }

  return (
    <div ref={containerRef} className={`relative overflow-hidden ${className}`} onMouseMove={handleMouseMove}>
      {/* Background gradient */}
      <div className={`absolute inset-0 bg-gradient-to-br ${getBackgroundGradient()} pointer-events-none`} />

      {/* Canvas for particle effects */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 pointer-events-none"
        style={{ width: "100%", height: "100%" }}
      />

      {/* Emission level indicator */}
      <div className="absolute top-4 left-4 z-20">
        <div
          className={`px-3 py-1 rounded-full text-sm font-medium backdrop-blur-sm ${
            emissionLevel === "high"
              ? "bg-red-500/20 text-red-200 border border-red-500/30"
              : emissionLevel === "medium"
                ? "bg-yellow-500/20 text-yellow-200 border border-yellow-500/30"
                : emissionLevel === "low"
                  ? "bg-green-500/20 text-green-200 border border-green-500/30"
                  : "bg-emerald-500/20 text-emerald-200 border border-emerald-500/30"
          }`}
        >
          {emissionLevel === "high"
            ? "🔴 High Emissions"
            : emissionLevel === "medium"
              ? "🟡 Medium Emissions"
              : emissionLevel === "low"
                ? "🟢 Low Emissions"
                : "✅ Carbon Negative"}
        </div>
      </div>

      {/* Content */}
      <div className="relative z-10">{children}</div>
    </div>
  )
}
