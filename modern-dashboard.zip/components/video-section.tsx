"use client"

import { useRef, useEffect } from "react"

interface VideoSectionProps {
  src: string
  title: string
  description: string
}

export function VideoSection({ src, title, description }: VideoSectionProps) {
  const videoRef = useRef<HTMLVideoElement>(null)

  useEffect(() => {
    const video = videoRef.current
    if (!video) return

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            video.play()
          } else {
            video.pause()
          }
        })
      },
      { threshold: 0.5 },
    )

    observer.observe(video)

    return () => {
      observer.disconnect()
    }
  }, [])

  return (
    <div className="w-full max-w-4xl mx-auto p-6">
      <div className="text-center mb-6">
        <h2 className="text-2xl font-bold text-gray-800 mb-2">{title}</h2>
        <p className="text-gray-600">{description}</p>
      </div>
      <div className="relative rounded-lg overflow-hidden shadow-lg">
        <video ref={videoRef} src={src} loop muted playsInline className="w-full h-auto" crossOrigin="anonymous" />
      </div>
    </div>
  )
}
