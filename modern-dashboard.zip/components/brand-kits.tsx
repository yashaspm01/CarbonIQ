"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { MoreHorizontal } from "lucide-react"

interface BrandKit {
  id: string
  name: string
  color: string
  checked: boolean
}

export function BrandKits() {
  const [brandKits, setBrandKits] = useState<BrandKit[]>([
    { id: "1", name: "ECorp", color: "bg-emerald-500", checked: false },
    { id: "2", name: "ICorp", color: "bg-orange-500", checked: false },
    { id: "3", name: "The Agency", color: "bg-red-500", checked: true },
  ])

  const toggleBrandKit = (id: string) => {
    setBrandKits((prev) => prev.map((kit) => (kit.id === id ? { ...kit, checked: !kit.checked } : kit)))
  }

  return (
    <div className="w-full max-w-md mx-auto p-6 bg-black rounded-2xl border border-purple-500/30 relative overflow-hidden">
      {/* Gradient border effect */}
      <div className="absolute inset-0 bg-gradient-to-r from-purple-500 via-blue-500 to-cyan-500 rounded-2xl opacity-30 blur-sm"></div>
      <div className="relative bg-black rounded-xl p-6">
        <h2 className="text-white text-xl font-semibold mb-6">Brand Kits</h2>

        <div className="space-y-3">
          {brandKits.map((kit) => (
            <Card key={kit.id} className="bg-gray-900/50 border-gray-700 p-4 hover:bg-gray-800/50 transition-colors">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <Checkbox
                    checked={kit.checked}
                    onCheckedChange={() => toggleBrandKit(kit.id)}
                    className="border-gray-600 data-[state=checked]:bg-purple-600 data-[state=checked]:border-purple-600"
                  />
                  <div className="flex items-center space-x-3">
                    <div className={`w-6 h-6 rounded-full ${kit.color}`}></div>
                    <span className="text-white font-medium">{kit.name}</span>
                  </div>
                </div>
                <MoreHorizontal className="w-5 h-5 text-gray-400 hover:text-white cursor-pointer" />
              </div>
            </Card>
          ))}
        </div>
      </div>
    </div>
  )
}
