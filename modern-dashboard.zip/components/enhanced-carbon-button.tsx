"use client"

import type React from "react"
import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"

interface CarbonEmissionRipple {
  id: number
  x: number
  y: number
  timestamp: number
  carbonSaved: number
}

interface EnhancedCarbonButtonProps {
  children: React.ReactNode
  onClick?: () => void
  className?: string
  variant?: "default" | "outline" | "ghost"
  size?: "default" | "sm" | "lg"
  disabled?: boolean
  carbonImpact?: number // kg CO₂ saved/reduced
  emissionType?: "reduction" | "neutral" | "negative"
}

export function EnhancedCarbonButton({
  children,
  onClick,
  className = "",
  variant = "default",
  size = "default",
  disabled = false,
  carbonImpact = 0,
  emissionType = "reduction",
}: EnhancedCarbonButtonProps) {
  const [ripples, setRipples] = useState<CarbonEmissionRipple[]>([])
  const [isHovered, setIsHovered] = useState(false)
  const buttonRef = useRef<HTMLButtonElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)

  // Canvas animation for carbon molecules
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const resizeCanvas = () => {
      if (buttonRef.current) {
        const rect = buttonRef.current.getBoundingClientRect()
        canvas.width = rect.width
        canvas.height = rect.height
      }
    }

    resizeCanvas()

    let animationId: number
    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height)

      // Draw carbon emission ripples
      ripples.forEach((ripple) => {
        const age = Date.now() - ripple.timestamp
        const maxAge = 1500
        const progress = age / maxAge

        if (progress < 1) {
          const radius = progress * 100
          const opacity = (1 - progress) * 0.8

          // Create carbon reduction gradient
          const gradient = ctx.createRadialGradient(ripple.x, ripple.y, 0, ripple.x, ripple.y, radius)

          if (emissionType === "reduction") {
            gradient.addColorStop(0, `rgba(34, 197, 94, ${opacity})`)
            gradient.addColorStop(0.5, `rgba(74, 222, 128, ${opacity * 0.6})`)
            gradient.addColorStop(1, `rgba(187, 247, 208, ${opacity * 0.2})`)
          } else if (emissionType === "negative") {
            gradient.addColorStop(0, `rgba(16, 185, 129, ${opacity})`)
            gradient.addColorStop(0.5, `rgba(52, 211, 153, ${opacity * 0.6})`)
            gradient.addColorStop(1, `rgba(167, 243, 208, ${opacity * 0.2})`)
          } else {
            gradient.addColorStop(0, `rgba(59, 130, 246, ${opacity})`)
            gradient.addColorStop(0.5, `rgba(147, 197, 253, ${opacity * 0.6})`)
            gradient.addColorStop(1, `rgba(219, 234, 254, ${opacity * 0.2})`)
          }

          ctx.fillStyle = gradient
          ctx.beginPath()
          ctx.arc(ripple.x, ripple.y, radius, 0, Math.PI * 2)
          ctx.fill()

          // Draw carbon savings indicator
          if (ripple.carbonSaved > 0 && progress < 0.7) {
            ctx.fillStyle = `rgba(34, 197, 94, ${opacity})`
            ctx.font = "12px Inter, sans-serif"
            ctx.textAlign = "center"
            ctx.fillText(`-${ripple.carbonSaved}kg CO₂`, ripple.x, ripple.y - 10)
          }

          // Draw CO₂ molecules being absorbed
          for (let i = 0; i < 6; i++) {
            const angle = (i / 6) * Math.PI * 2 + progress * Math.PI * 2
            const moleculeRadius = radius * 0.6
            const moleculeX = ripple.x + Math.cos(angle) * moleculeRadius * (1 - progress)
            const moleculeY = ripple.y + Math.sin(angle) * moleculeRadius * (1 - progress)

            // Draw CO₂ molecule
            ctx.fillStyle = `rgba(34, 197, 94, ${opacity * 0.8})`
            ctx.beginPath()
            ctx.arc(moleculeX, moleculeY, 2, 0, Math.PI * 2)
            ctx.fill()

            // Add small trail
            ctx.fillStyle = `rgba(34, 197, 94, ${opacity * 0.4})`
            ctx.beginPath()
            ctx.arc(moleculeX - Math.cos(angle) * 5, moleculeY - Math.sin(angle) * 5, 1, 0, Math.PI * 2)
            ctx.fill()
          }
        }
      })

      // Draw hover effect molecules
      if (isHovered && canvas.width > 0) {
        const time = Date.now() * 0.001
        for (let i = 0; i < 8; i++) {
          const angle = (i / 8) * Math.PI * 2 + time
          const x = canvas.width / 2 + Math.cos(angle) * 20
          const y = canvas.height / 2 + Math.sin(angle) * 10

          ctx.fillStyle = `rgba(34, 197, 94, 0.6)`
          ctx.beginPath()
          ctx.arc(x, y, 1.5, 0, Math.PI * 2)
          ctx.fill()
        }
      }

      animationId = requestAnimationFrame(animate)
    }

    animate()

    return () => {
      if (animationId) {
        cancelAnimationFrame(animationId)
      }
    }
  }, [ripples, isHovered, emissionType])

  const createCarbonRipple = (event: React.MouseEvent) => {
    if (disabled || !buttonRef.current || !canvasRef.current) return

    const rect = buttonRef.current.getBoundingClientRect()
    const canvasRect = canvasRef.current.getBoundingClientRect()
    const x = event.clientX - canvasRect.left
    const y = event.clientY - canvasRect.top

    const newRipple: CarbonEmissionRipple = {
      id: Date.now() + Math.random(),
      x,
      y,
      timestamp: Date.now(),
      carbonSaved: carbonImpact,
    }

    setRipples((prev) => [...prev, newRipple])

    // Clean up old ripples
    setTimeout(() => {
      setRipples((prev) => prev.filter((ripple) => ripple.id !== newRipple.id))
    }, 1500)

    onClick?.()
  }

  const getButtonStyles = () => {
    const baseStyles = "relative overflow-hidden transition-all duration-300"

    if (emissionType === "reduction") {
      return `${baseStyles} hover:shadow-lg hover:shadow-green-500/25 border-green-500/30`
    } else if (emissionType === "negative") {
      return `${baseStyles} hover:shadow-lg hover:shadow-emerald-500/25 border-emerald-500/30`
    }

    return `${baseStyles} hover:shadow-lg hover:shadow-blue-500/25 border-blue-500/30`
  }

  return (
    <div className="relative inline-block">
      <Button
        ref={buttonRef}
        variant={variant}
        size={size}
        disabled={disabled}
        className={`${getButtonStyles()} ${className}`}
        onClick={createCarbonRipple}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        {/* Canvas for carbon effects */}
        <canvas
          ref={canvasRef}
          className="absolute inset-0 pointer-events-none"
          style={{ width: "100%", height: "100%" }}
        />

        {/* Content */}
        <span className="relative z-10 flex items-center gap-2">
          {children}
          {carbonImpact > 0 && <span className="text-xs opacity-75">(-{carbonImpact}kg CO₂)</span>}
        </span>

        {/* Carbon impact indicator */}
        {carbonImpact > 0 && (
          <div className="absolute -top-2 -right-2 bg-green-500 text-white text-xs px-1.5 py-0.5 rounded-full font-medium">
            -{carbonImpact}kg
          </div>
        )}
      </Button>

      {/* Hover tooltip */}
      {isHovered && carbonImpact > 0 && (
        <div className="absolute -top-12 left-1/2 transform -translate-x-1/2 bg-black text-white text-xs px-2 py-1 rounded whitespace-nowrap z-20">
          Saves {carbonImpact}kg CO₂ emissions
          <div className="absolute top-full left-1/2 transform -translate-x-1/2 border-4 border-transparent border-t-black" />
        </div>
      )}
    </div>
  )
}
