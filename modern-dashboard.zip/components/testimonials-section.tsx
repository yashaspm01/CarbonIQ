"use client"

import { useEffect, useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Star, Quote } from "lucide-react"

/**
 * Slimmed-down testimonials – no video element.
 * The section auto-cycles every 6 s and shows dot indicators.
 */

const testimonials = [
  {
    name: "Dr. Sarah Chen",
    role: "Chief Sustainability Officer · EcoTech Properties",
    content:
      "CarbonIQ's embodied-carbon analysis transformed our approach to construction. \
We reduced our portfolio's carbon footprint by 42 % and hit net-zero targets three years early.",
    reduction: "42 %",
    avatar: "/placeholder.svg?height=60&width=60",
  },
  {
    name: "Michael Rodriguez",
    role: "Head of Sustainable Design · GreenBuild Architects",
    content:
      "The platform helped us optimise material selection from day one. \
Our latest project achieved a 38 % embodied-carbon cut while staying on budget.",
    reduction: "38 %",
    avatar: "/placeholder.svg?height=60&width=60",
  },
  {
    name: "Emma Thompson",
    role: "Portfolio Manager · Carbon Neutral Investments",
    content:
      "Real-time tracking and predictive analytics enabled portfolio-wide LEED Platinum certification. \
Reporting has never been so effortless.",
    reduction: "45 %",
    avatar: "/placeholder.svg?height=60&width=60",
  },
]

export function TestimonialsSection() {
  const [index, setIndex] = useState(0)

  useEffect(() => {
    const id = setInterval(() => setIndex((i) => (i + 1) % testimonials.length), 6000)
    return () => clearInterval(id)
  }, [])

  return (
    <section
      id="testimonials"
      className="py-16 bg-gradient-to-br from-green-50 to-blue-50 dark:from-gray-900 dark:to-gray-800"
    >
      <div className="container px-4 mx-auto max-w-5xl text-center">
        <h2 className="text-4xl font-bold text-gray-900 dark:text-white mb-2">Carbon Intelligence Success Stories</h2>
        <p className="text-lg text-gray-600 dark:text-gray-300 mb-12">
          Organisations achieving remarkable reductions with CarbonIQ
        </p>

        {/* Carousel */}
        <div className="overflow-hidden">
          <div
            className="flex transition-transform duration-700 ease-in-out"
            style={{ transform: `translateX(-${index * 100}%)` }}
          >
            {testimonials.map((t, i) => (
              <Card key={i} className="flex-shrink-0 w-full bg-white dark:bg-gray-800 border-0 shadow-lg">
                <CardContent className="p-8 md:p-12">
                  <Quote className="w-8 h-8 text-green-500 mb-4 inline" />
                  <div className="flex mb-4">
                    {[...Array(5)].map((_, s) => (
                      <Star key={s} className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                  <p className="text-gray-700 dark:text-gray-300 text-lg mb-6 leading-relaxed">{t.content}</p>
                  <div className="flex items-center justify-center gap-4">
                    <img
                      src={t.avatar || "/placeholder.svg"}
                      alt={t.name}
                      className="w-12 h-12 rounded-full ring-2 ring-green-500"
                    />
                    <div className="text-left">
                      <h4 className="font-semibold text-gray-900 dark:text-white">{t.name}</h4>
                      <span className="text-sm text-gray-600 dark:text-gray-400">{t.role}</span>
                    </div>
                  </div>
                  <div className="mt-6 text-green-600 dark:text-green-400 font-bold">
                    {t.reduction} carbon reduction
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Dots */}
        <div className="flex justify-center gap-2 mt-6">
          {testimonials.map((_, i) => (
            <button
              key={i}
              aria-label={`Show testimonial ${i + 1}`}
              onClick={() => setIndex(i)}
              className={`w-3 h-3 rounded-full transition-colors ${
                i === index ? "bg-green-600" : "bg-gray-300 dark:bg-gray-600"
              }`}
            />
          ))}
        </div>
      </div>
    </section>
  )
}
