"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { EnhancedCarbonButton } from "./enhanced-carbon-button"
import { Badge } from "@/components/ui/badge"
import { Download, Eye, BarChart3, Filter } from "lucide-react"
import { CarbonEmissionBackground } from "./carbon-emission-background"
import { PortfolioImageGenerator } from "./portfolio-image-generator"

interface PortfolioProject {
  id: string
  name: string
  type: "office" | "residential" | "retail" | "industrial"
  status: "completed" | "in-progress" | "planned"
  carbonFootprint: number
  energyIntensity: number
  energyConsumption: number
  carbonReduction: number
  certifications: string[]
  location: string
  completionDate: string
}

const portfolioProjects: PortfolioProject[] = [
  {
    id: "1",
    name: "EcoTower One",
    type: "office",
    status: "completed",
    carbonFootprint: 285,
    energyIntensity: 95,
    energyConsumption: 2450000,
    carbonReduction: 42,
    certifications: ["LEED Platinum", "BREEAM Outstanding"],
    location: "London, UK",
    completionDate: "2023",
  },
  {
    id: "2",
    name: "Green Residences",
    type: "residential",
    status: "completed",
    carbonFootprint: 320,
    energyIntensity: 78,
    energyConsumption: 1850000,
    carbonReduction: 38,
    certifications: ["LEED Gold", "Energy Star"],
    location: "Manchester, UK",
    completionDate: "2023",
  },
  {
    id: "3",
    name: "Sustainable Mall",
    type: "retail",
    status: "in-progress",
    carbonFootprint: 450,
    energyIntensity: 125,
    energyConsumption: 3200000,
    carbonReduction: 35,
    certifications: ["BREEAM Excellent"],
    location: "Birmingham, UK",
    completionDate: "2024",
  },
  {
    id: "4",
    name: "Smart Factory",
    type: "industrial",
    status: "completed",
    carbonFootprint: 680,
    energyIntensity: 180,
    energyConsumption: 5400000,
    carbonReduction: 28,
    certifications: ["ISO 14001", "Carbon Trust"],
    location: "Leeds, UK",
    completionDate: "2022",
  },
  {
    id: "5",
    name: "Future Offices",
    type: "office",
    status: "planned",
    carbonFootprint: 220,
    energyIntensity: 65,
    energyConsumption: 1950000,
    carbonReduction: 45,
    certifications: ["LEED Platinum (Target)"],
    location: "Edinburgh, UK",
    completionDate: "2025",
  },
  {
    id: "6",
    name: "Urban Living",
    type: "residential",
    status: "in-progress",
    carbonFootprint: 295,
    energyIntensity: 72,
    energyConsumption: 2100000,
    carbonReduction: 40,
    certifications: ["BREEAM Very Good"],
    location: "Bristol, UK",
    completionDate: "2024",
  },
]

export function InteractivePortfolio() {
  const [selectedType, setSelectedType] = useState<string>("all")
  const [selectedStatus, setSelectedStatus] = useState<string>("all")
  const [selectedProject, setSelectedProject] = useState<PortfolioProject | null>(null)

  const filteredProjects = portfolioProjects.filter((project) => {
    const typeMatch = selectedType === "all" || project.type === selectedType
    const statusMatch = selectedStatus === "all" || project.status === selectedStatus
    return typeMatch && statusMatch
  })

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200"
      case "in-progress":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200"
      case "planned":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200"
    }
  }

  const getTypeColor = (type: string) => {
    switch (type) {
      case "office":
        return "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200"
      case "residential":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200"
      case "retail":
        return "bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200"
      case "industrial":
        return "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200"
    }
  }

  return (
    <CarbonEmissionBackground
      className="py-12 md:py-20 bg-white dark:bg-gray-900"
      emissionLevel="negative"
      interactive={true}
      particleCount={25}
    >
      <section id="portfolio">
        <div className="container mx-auto px-4 relative z-10">
          <div className="text-center mb-12 md:mb-16">
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-gray-900 dark:text-white mb-4">
              Interactive Portfolio
            </h2>
            <p className="text-lg md:text-xl text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
              Explore our sustainable building projects with real-time carbon analytics and performance metrics
            </p>
          </div>

          {/* Filters */}
          <div className="flex flex-wrap gap-4 mb-8 justify-center">
            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4 text-gray-600 dark:text-gray-400" />
              <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Type:</span>
              <select
                value={selectedType}
                onChange={(e) => setSelectedType(e.target.value)}
                className="px-3 py-1 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-800 text-gray-900 dark:text-white text-sm"
              >
                <option value="all">All Types</option>
                <option value="office">Office</option>
                <option value="residential">Residential</option>
                <option value="retail">Retail</option>
                <option value="industrial">Industrial</option>
              </select>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Status:</span>
              <select
                value={selectedStatus}
                onChange={(e) => setSelectedStatus(e.target.value)}
                className="px-3 py-1 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-800 text-gray-900 dark:text-white text-sm"
              >
                <option value="all">All Status</option>
                <option value="completed">Completed</option>
                <option value="in-progress">In Progress</option>
                <option value="planned">Planned</option>
              </select>
            </div>
          </div>

          {/* Portfolio Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
            {filteredProjects.map((project) => (
              <Card
                key={project.id}
                className="group hover:shadow-xl transition-all duration-300 cursor-pointer bg-white dark:bg-gray-800 border-0 shadow-lg"
                onClick={() => setSelectedProject(project)}
              >
                <CardContent className="p-0">
                  <div className="relative">
                    <PortfolioImageGenerator
                      type={project.type}
                      name={project.name}
                      width={300}
                      height={200}
                      carbonReduction={project.carbonReduction}
                    />
                    <div className="absolute top-4 left-4 flex gap-2">
                      <Badge className={getStatusColor(project.status)}>{project.status}</Badge>
                      <Badge className={getTypeColor(project.type)}>{project.type}</Badge>
                    </div>
                  </div>

                  <div className="p-6">
                    <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">{project.name}</h3>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
                      {project.location} • {project.completionDate}
                    </p>

                    {/* Key Metrics */}
                    <div className="grid grid-cols-3 gap-4 mb-4">
                      <div className="text-center">
                        <div className="text-lg font-semibold text-gray-900 dark:text-white">
                          {project.carbonFootprint}
                        </div>
                        <div className="text-xs text-gray-600 dark:text-gray-400">tCO₂e</div>
                      </div>
                      <div className="text-center">
                        <div className="text-lg font-semibold text-gray-900 dark:text-white">
                          {project.energyIntensity}
                        </div>
                        <div className="text-xs text-gray-600 dark:text-gray-400">kWh/m²</div>
                      </div>
                      <div className="text-center">
                        <div className="text-lg font-semibold text-green-600 dark:text-green-400">
                          -{project.carbonReduction}%
                        </div>
                        <div className="text-xs text-gray-600 dark:text-gray-400">Reduction</div>
                      </div>
                    </div>

                    {/* Certifications */}
                    <div className="flex flex-wrap gap-1 mb-4">
                      {project.certifications.slice(0, 2).map((cert, index) => (
                        <Badge key={index} variant="secondary" className="text-xs">
                          {cert}
                        </Badge>
                      ))}
                      {project.certifications.length > 2 && (
                        <Badge variant="secondary" className="text-xs">
                          +{project.certifications.length - 2}
                        </Badge>
                      )}
                    </div>

                    <div className="flex gap-2">
                      <EnhancedCarbonButton size="sm" className="flex-1 bg-gradient-to-r from-green-500 to-blue-500">
                        <Eye className="w-4 h-4 mr-2" />
                        View Details
                      </EnhancedCarbonButton>
                      <EnhancedCarbonButton size="sm" variant="outline" className="flex-1">
                        <BarChart3 className="w-4 h-4 mr-2" />
                        Analytics
                      </EnhancedCarbonButton>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Project Detail Modal */}
          {selectedProject && (
            <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
              <div className="bg-white dark:bg-gray-800 rounded-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto">
                <div className="p-6">
                  <div className="flex justify-between items-start mb-6">
                    <div>
                      <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">{selectedProject.name}</h2>
                      <p className="text-gray-600 dark:text-gray-400">
                        {selectedProject.location} • {selectedProject.completionDate}
                      </p>
                    </div>
                    <EnhancedCarbonButton variant="ghost" onClick={() => setSelectedProject(null)}>
                      ×
                    </EnhancedCarbonButton>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <PortfolioImageGenerator
                        type={selectedProject.type}
                        name={selectedProject.name}
                        width={400}
                        height={300}
                        carbonReduction={selectedProject.carbonReduction}
                      />
                      <div className="space-y-4 mt-4">
                        <div>
                          <h3 className="font-semibold text-gray-900 dark:text-white mb-2">Certifications</h3>
                          <div className="flex flex-wrap gap-2">
                            {selectedProject.certifications.map((cert, index) => (
                              <Badge key={index} variant="secondary">
                                {cert}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-6">
                      <div>
                        <h3 className="font-semibold text-gray-900 dark:text-white mb-4">Performance Metrics</h3>
                        <div className="space-y-4">
                          <div className="flex justify-between items-center">
                            <span className="text-gray-600 dark:text-gray-400">Carbon Footprint</span>
                            <span className="font-semibold text-gray-900 dark:text-white">
                              {selectedProject.carbonFootprint} tCO₂e
                            </span>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-gray-600 dark:text-gray-400">Energy Intensity</span>
                            <span className="font-semibold text-gray-900 dark:text-white">
                              {selectedProject.energyIntensity} kWh/m²
                            </span>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-gray-600 dark:text-gray-400">Energy Consumption</span>
                            <span className="font-semibold text-gray-900 dark:text-white">
                              {selectedProject.energyConsumption.toLocaleString()} kWh
                            </span>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-gray-600 dark:text-gray-400">Carbon Reduction</span>
                            <span className="font-semibold text-green-600 dark:text-green-400">
                              -{selectedProject.carbonReduction}%
                            </span>
                          </div>
                        </div>
                      </div>

                      <div className="flex gap-2">
                        <EnhancedCarbonButton className="flex-1 bg-gradient-to-r from-green-500 to-blue-500">
                          <Download className="w-4 h-4 mr-2" />
                          Download Report
                        </EnhancedCarbonButton>
                        <EnhancedCarbonButton variant="outline" className="flex-1">
                          <BarChart3 className="w-4 h-4 mr-2" />
                          View Analytics
                        </EnhancedCarbonButton>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </section>
    </CarbonEmissionBackground>
  )
}
