"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Download } from "lucide-react"
import { Bar, BarChart, ResponsiveContainer, XAxis, YAxis, ReferenceLine } from "recharts"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"

const data = [
  { name: "Project 1", value: 549, type: "refurbishment" },
  { name: "Project 2", value: 278, type: "refurbishment" },
  { name: "Project 3", value: 875, type: "new" },
  { name: "Project 4", value: 617, type: "new" },
  { name: "Project 5", value: 506, type: "refurbishment" },
  { name: "Project 6", value: 36, type: "refurbishment" },
  { name: "Project 7", value: 185, type: "new" },
  { name: "Project 8", value: 191, type: "new" },
  { name: "Project 9", value: 122, type: "refurbishment" },
  { name: "Project 10", value: 550, type: "new" },
  { name: "Project 11", value: 881, type: "new" },
  { name: "Project 12", value: 539, type: "refurbishment" },
  { name: "Project 13", value: 269, type: "refurbishment" },
  { name: "Project 14", value: 29, type: "new" },
  { name: "Project 15", value: 82, type: "refurbishment" },
  { name: "Project 16", value: 44, type: "new" },
  { name: "Project 17", value: 109, type: "refurbishment" },
  { name: "Project 18", value: 106, type: "new" },
  { name: "Project 19", value: 607, type: "new" },
  { name: "Project 20", value: 528, type: "refurbishment" },
]

export function CarbonEmissionsChart() {
  const [typeFilter, setTypeFilter] = useState<"all" | "refurbishment" | "new">("all")
  const [statusFilter, setStatusFilter] = useState<"complete" | "estimate">("complete")

  const filteredData = data.filter((item) => typeFilter === "all" || item.type === typeFilter)

  return (
    <div className="w-full max-w-6xl mx-auto p-6 bg-gray-50 min-h-screen">
      <div className="flex justify-between items-start mb-8">
        <div>
          <h1 className="text-4xl font-light text-gray-800 mb-2">
            EMBODIED
            <br />
            <span className="text-red-800">
              CARBON
              <br />
              EMISSIONS
            </span>
          </h1>
          <p className="text-gray-600 text-sm">Intensity measured by kgCO₂e/m²</p>
        </div>
        <Button variant="outline" className="flex items-center gap-2">
          <Download className="w-4 h-4" />
          Download the data
        </Button>
      </div>

      <div className="mb-6">
        <div className="mb-4">
          <h3 className="text-sm font-medium text-gray-700 mb-2">Filter by</h3>
          <div className="flex gap-2 mb-4">
            <span className="text-sm text-gray-600">Type</span>
            <Button
              variant={typeFilter === "refurbishment" ? "default" : "outline"}
              size="sm"
              onClick={() => setTypeFilter("refurbishment")}
              className="rounded-full"
            >
              Refurbishment
            </Button>
            <Button
              variant={typeFilter === "new" ? "default" : "outline"}
              size="sm"
              onClick={() => setTypeFilter("new")}
              className="rounded-full"
            >
              New build
            </Button>
            <Button
              variant={typeFilter === "all" ? "default" : "outline"}
              size="sm"
              onClick={() => setTypeFilter("all")}
              className="rounded-full bg-red-800 hover:bg-red-700 text-white"
            >
              All
            </Button>
          </div>
          <div className="flex gap-2">
            <span className="text-sm text-gray-600">Status</span>
            <Button
              variant={statusFilter === "complete" ? "default" : "outline"}
              size="sm"
              onClick={() => setStatusFilter("complete")}
              className="rounded-full bg-red-800 hover:bg-red-700 text-white"
            >
              Complete
            </Button>
            <Button
              variant={statusFilter === "estimate" ? "default" : "outline"}
              size="sm"
              onClick={() => setStatusFilter("estimate")}
              className="rounded-full"
            >
              Estimate
            </Button>
          </div>
        </div>

        <div className="mb-4">
          <h3 className="text-sm font-medium text-gray-700 mb-2">Key</h3>
          <div className="space-y-1 text-sm text-gray-600">
            <div className="flex items-center gap-2">
              <div className="w-4 h-0.5 border-t-2 border-dashed border-gray-400"></div>
              <span>500 kgCO₂e/m² - Embodied Carbon Target 2030</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-0.5 bg-gray-600"></div>
              <span>600 kgCO₂e/m² - Embodied Carbon Target 2025</span>
            </div>
          </div>
        </div>
      </div>

      <Card className="bg-white">
        <CardContent className="p-6">
          <ChartContainer
            config={{
              value: {
                label: "Embodied carbon intensity (kgCO₂e/m²)",
                color: "hsl(var(--chart-1))",
              },
            }}
            className="h-96"
          >
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={filteredData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                <XAxis dataKey="name" tick={false} />
                <YAxis
                  domain={[0, 1200]}
                  label={{ value: "Embodied carbon intensity (kgCO₂e/m²)", angle: -90, position: "insideLeft" }}
                />
                <ChartTooltip content={<ChartTooltipContent />} />
                <ReferenceLine y={500} stroke="#666" strokeDasharray="5 5" />
                <ReferenceLine y={600} stroke="#666" />
                <Bar dataKey="value" fill="#8B4513" radius={[2, 2, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </ChartContainer>
        </CardContent>
      </Card>
    </div>
  )
}
