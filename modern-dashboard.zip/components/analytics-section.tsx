"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Download, TrendingDown, TrendingUp } from "lucide-react"
import { CustomCarbonChart } from "./custom-carbon-chart"

const portfolioMetrics = [
  {
    title: "Managed portfolio carbon footprint",
    unit: "tCO₂e",
    currentValue: "45,048",
    changeFromBaseline: 16,
    isPositive: false,
    data: [
      { year: 2022, value: 45048, percentage: 100 },
      { year: 2021, value: 14111, percentage: 31 },
      { year: 2020, value: 32813, percentage: 73 },
      { year: 2019, value: 38673, percentage: 86 },
    ],
  },
  {
    title: "Managed portfolio energy intensity",
    unit: "kWh/m²",
    currentValue: "123",
    changeFromBaseline: -22,
    isPositive: true,
    data: [
      { year: 2022, value: 123, percentage: 78 },
      { year: 2021, value: 128, percentage: 82 },
      { year: 2020, value: 135, percentage: 86 },
      { year: 2019, value: 157, percentage: 100 },
    ],
  },
  {
    title: "Managed portfolio energy consumption",
    unit: "kWh",
    currentValue: "47,790,662",
    changeFromBaseline: -27,
    isPositive: true,
    data: [
      { year: 2022, value: 47790662, percentage: 73 },
      { year: 2021, value: 49324077, percentage: 76 },
      { year: 2020, value: 48784205, percentage: 75 },
      { year: 2019, value: 65198706, percentage: 100 },
    ],
  },
]

export function AnalyticsSection() {
  return (
    <section id="analytics" className="py-20 bg-white dark:bg-gray-900">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-4">Portfolio Analytics</h2>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
            Real-time insights and comprehensive analytics for your sustainable building portfolio
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
          {portfolioMetrics.map((metric, index) => (
            <Card
              key={index}
              className="bg-gray-50 dark:bg-gray-800 border-0 shadow-lg hover:shadow-xl transition-shadow"
            >
              <CardContent className="p-8">
                <div className="mb-6">
                  <h3 className="text-gray-700 dark:text-gray-300 text-lg font-medium mb-2 leading-tight">
                    {metric.title}
                  </h3>
                  <div className="flex items-baseline gap-2">
                    <span className="text-gray-500 dark:text-gray-400 text-sm">{metric.unit}</span>
                  </div>
                </div>

                <div className="mb-6">
                  <div className="text-4xl font-light text-gray-900 dark:text-white mb-2">{metric.currentValue}</div>
                  <div className="flex items-center gap-2 text-sm">
                    <span className="text-gray-500 dark:text-gray-400">from 2019</span>
                    <div className="flex items-center gap-1">
                      {metric.isPositive ? (
                        <TrendingDown className="w-4 h-4 text-green-600" />
                      ) : (
                        <TrendingUp className="w-4 h-4 text-red-600" />
                      )}
                      <span className={metric.isPositive ? "text-green-600" : "text-red-600"}>
                        {Math.abs(metric.changeFromBaseline)}%
                      </span>
                    </div>
                  </div>
                </div>

                <div className="space-y-4 mb-8">
                  {metric.data.map((item) => (
                    <div key={item.year} className="flex items-center gap-4">
                      <span className="text-gray-600 dark:text-gray-400 text-sm w-8">{item.year}</span>
                      <div className="flex-1 relative">
                        <div className="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-gradient-to-r from-green-500 to-blue-500 rounded-full transition-all duration-1000"
                            style={{ width: `${item.percentage}%` }}
                          />
                        </div>
                      </div>
                      <span className="text-gray-600 dark:text-gray-400 text-sm w-20 text-right">
                        {item.value.toLocaleString()}
                      </span>
                    </div>
                  ))}
                </div>

                <Button
                  variant="ghost"
                  className="w-full justify-between p-0 h-auto text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white group"
                >
                  <span className="text-sm">Download the data</span>
                  <Download className="w-4 h-4 group-hover:translate-y-0.5 transition-transform" />
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Custom Interactive Chart */}
        <div className="mt-20">
          <CustomCarbonChart />
        </div>
      </div>
    </section>
  )
}
