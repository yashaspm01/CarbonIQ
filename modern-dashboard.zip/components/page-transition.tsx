"use client"

import type React from "react"

import { useEffect, useState } from "react"

interface PageTransitionProps {
  children: React.ReactNode
}

export function PageTransition({ children }: PageTransitionProps) {
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(true)
    }, 100)

    return () => clearTimeout(timer)
  }, [])

  return (
    <div
      className={`transition-all duration-1000 ease-out ${
        isVisible ? "opacity-100 transform translate-y-0" : "opacity-0 transform translate-y-4"
      }`}
    >
      {children}
    </div>
  )
}
