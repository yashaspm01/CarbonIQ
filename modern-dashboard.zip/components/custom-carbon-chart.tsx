"use client"

import type React from "react"

import { useEffect, useRef, useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Download } from "lucide-react"

interface ChartDataPoint {
  name: string
  value: number
  type: "refurbishment" | "new"
  status: "complete" | "estimate"
  color: string
}

const chartData: ChartDataPoint[] = [
  { name: "Project 1", value: 549, type: "refurbishment", status: "complete", color: "#8B4513" },
  { name: "Project 2", value: 278, type: "refurbishment", status: "complete", color: "#A0522D" },
  { name: "Project 3", value: 875, type: "new", status: "complete", color: "#CD853F" },
  { name: "Project 4", value: 617, type: "new", status: "complete", color: "#D2691E" },
  { name: "Project 5", value: 506, type: "refurbishment", status: "complete", color: "#8B4513" },
  { name: "Project 6", value: 36, type: "refurbishment", status: "complete", color: "#A0522D" },
  { name: "Project 7", value: 185, type: "new", status: "complete", color: "#CD853F" },
  { name: "Project 8", value: 191, type: "new", status: "complete", color: "#D2691E" },
  { name: "Project 9", value: 122, type: "refurbishment", status: "complete", color: "#8B4513" },
  { name: "Project 10", value: 550, type: "new", status: "complete", color: "#CD853F" },
  { name: "Project 11", value: 881, type: "new", status: "complete", color: "#D2691E" },
  { name: "Project 12", value: 539, type: "refurbishment", status: "complete", color: "#A0522D" },
  { name: "Project 13", value: 269, type: "refurbishment", status: "complete", color: "#8B4513" },
  { name: "Project 14", value: 29, type: "new", status: "complete", color: "#CD853F" },
  { name: "Project 15", value: 82, type: "refurbishment", status: "complete", color: "#A0522D" },
  { name: "Project 16", value: 44, type: "new", status: "complete", color: "#D2691E" },
  { name: "Project 17", value: 109, type: "refurbishment", status: "complete", color: "#8B4513" },
  { name: "Project 18", value: 106, type: "new", status: "complete", color: "#CD853F" },
  { name: "Project 19", value: 607, type: "new", status: "complete", color: "#D2691E" },
  { name: "Project 20", value: 528, type: "refurbishment", status: "complete", color: "#A0522D" },
]

export function CustomCarbonChart() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [typeFilter, setTypeFilter] = useState<"all" | "refurbishment" | "new">("all")
  const [statusFilter, setStatusFilter] = useState<"complete" | "estimate">("complete")
  const [hoveredBar, setHoveredBar] = useState<number | null>(null)

  const filteredData = chartData.filter((item) => typeFilter === "all" || item.type === typeFilter)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Set canvas size
    const rect = canvas.getBoundingClientRect()
    canvas.width = rect.width * window.devicePixelRatio
    canvas.height = rect.height * window.devicePixelRatio
    ctx.scale(window.devicePixelRatio, window.devicePixelRatio)

    const width = rect.width
    const height = rect.height
    const padding = { top: 40, right: 40, bottom: 80, left: 80 }
    const chartWidth = width - padding.left - padding.right
    const chartHeight = height - padding.top - padding.bottom

    // Clear canvas
    ctx.clearRect(0, 0, width, height)

    // Draw background
    ctx.fillStyle = "#ffffff"
    ctx.fillRect(0, 0, width, height)

    // Calculate scales
    const maxValue = Math.max(...filteredData.map((d) => d.value))
    const barWidth = chartWidth / filteredData.length
    const scaleY = chartHeight / (maxValue * 1.2) // Add 20% padding

    // Draw grid lines
    ctx.strokeStyle = "#e5e7eb"
    ctx.lineWidth = 1
    for (let i = 0; i <= 10; i++) {
      const y = padding.top + (chartHeight / 10) * i
      ctx.beginPath()
      ctx.moveTo(padding.left, y)
      ctx.lineTo(padding.left + chartWidth, y)
      ctx.stroke()
    }

    // Draw reference lines
    const target2030Y = padding.top + chartHeight - 500 * scaleY
    const target2025Y = padding.top + chartHeight - 600 * scaleY

    // 2030 target (dashed line)
    ctx.strokeStyle = "#9ca3af"
    ctx.lineWidth = 2
    ctx.setLineDash([5, 5])
    ctx.beginPath()
    ctx.moveTo(padding.left, target2030Y)
    ctx.lineTo(padding.left + chartWidth, target2030Y)
    ctx.stroke()

    // 2025 target (solid line)
    ctx.setLineDash([])
    ctx.strokeStyle = "#6b7280"
    ctx.lineWidth = 2
    ctx.beginPath()
    ctx.moveTo(padding.left, target2025Y)
    ctx.lineTo(padding.left + chartWidth, target2025Y)
    ctx.stroke()

    // Draw bars
    filteredData.forEach((item, index) => {
      const x = padding.left + index * barWidth + barWidth * 0.1
      const barHeight = item.value * scaleY
      const y = padding.top + chartHeight - barHeight
      const actualBarWidth = barWidth * 0.8

      // Bar color with hover effect
      let fillColor = item.color
      if (hoveredBar === index) {
        fillColor = item.type === "refurbishment" ? "#D2691E" : "#8B4513"
      }

      // Draw bar
      ctx.fillStyle = fillColor
      ctx.fillRect(x, y, actualBarWidth, barHeight)

      // Draw bar border
      ctx.strokeStyle = "#ffffff"
      ctx.lineWidth = 1
      ctx.strokeRect(x, y, actualBarWidth, barHeight)

      // Draw value on top of bar
      if (barHeight > 20) {
        ctx.fillStyle = "#374151"
        ctx.font = "12px Inter, sans-serif"
        ctx.textAlign = "center"
        ctx.fillText(item.value.toString(), x + actualBarWidth / 2, y - 5)
      }
    })

    // Draw Y-axis labels
    ctx.fillStyle = "#6b7280"
    ctx.font = "12px Inter, sans-serif"
    ctx.textAlign = "right"
    for (let i = 0; i <= 10; i++) {
      const value = (maxValue * 1.2 * i) / 10
      const y = padding.top + chartHeight - (chartHeight / 10) * i
      ctx.fillText(Math.round(value).toString(), padding.left - 10, y + 4)
    }

    // Draw Y-axis title
    ctx.save()
    ctx.translate(20, padding.top + chartHeight / 2)
    ctx.rotate(-Math.PI / 2)
    ctx.fillStyle = "#374151"
    ctx.font = "14px Inter, sans-serif"
    ctx.textAlign = "center"
    ctx.fillText("Embodied carbon intensity (kgCO₂e/m²)", 0, 0)
    ctx.restore()

    // Draw X-axis labels
    ctx.fillStyle = "#6b7280"
    ctx.font = "10px Inter, sans-serif"
    ctx.textAlign = "center"
    filteredData.forEach((item, index) => {
      const x = padding.left + index * barWidth + barWidth / 2
      const y = padding.top + chartHeight + 20
      ctx.fillText(item.name, x, y)
    })

    // Draw legend
    const legendY = height - 40
    const legendItems = [
      { label: "500 kgCO₂e/m² - Embodied Carbon Target 2030", style: "dashed" },
      { label: "600 kgCO₂e/m² - Embodied Carbon Target 2025", style: "solid" },
    ]

    legendItems.forEach((item, index) => {
      const x = padding.left + index * 300

      // Draw line
      ctx.strokeStyle = "#6b7280"
      ctx.lineWidth = 2
      if (item.style === "dashed") {
        ctx.setLineDash([5, 5])
      } else {
        ctx.setLineDash([])
      }
      ctx.beginPath()
      ctx.moveTo(x, legendY)
      ctx.lineTo(x + 20, legendY)
      ctx.stroke()

      // Draw label
      ctx.fillStyle = "#6b7280"
      ctx.font = "12px Inter, sans-serif"
      ctx.textAlign = "left"
      ctx.fillText(item.label, x + 25, legendY + 4)
    })
  }, [filteredData, hoveredBar])

  const handleCanvasMouseMove = (event: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current
    if (!canvas) return

    const rect = canvas.getBoundingClientRect()
    const x = event.clientX - rect.left
    const y = event.clientY - rect.top

    const padding = { top: 40, right: 40, bottom: 80, left: 80 }
    const chartWidth = rect.width - padding.left - padding.right
    const barWidth = chartWidth / filteredData.length

    // Check if mouse is over a bar
    const barIndex = Math.floor((x - padding.left) / barWidth)
    if (barIndex >= 0 && barIndex < filteredData.length && y > padding.top && y < rect.height - padding.bottom) {
      setHoveredBar(barIndex)
    } else {
      setHoveredBar(null)
    }
  }

  return (
    <div className="w-full max-w-6xl mx-auto p-6 bg-gray-50 min-h-screen">
      <div className="flex justify-between items-start mb-8">
        <div>
          <h1 className="text-4xl font-light text-gray-800 mb-2">
            EMBODIED
            <br />
            <span className="text-red-800">
              CARBON
              <br />
              EMISSIONS
            </span>
          </h1>
          <p className="text-gray-600 text-sm">Intensity measured by kgCO₂e/m²</p>
        </div>
        <Button variant="outline" className="flex items-center gap-2">
          <Download className="w-4 h-4" />
          Download the data
        </Button>
      </div>

      <div className="mb-6">
        <div className="mb-4">
          <h3 className="text-sm font-medium text-gray-700 mb-2">Filter by</h3>
          <div className="flex gap-2 mb-4">
            <span className="text-sm text-gray-600">Type</span>
            <Button
              variant={typeFilter === "refurbishment" ? "default" : "outline"}
              size="sm"
              onClick={() => setTypeFilter("refurbishment")}
              className="rounded-full"
            >
              Refurbishment
            </Button>
            <Button
              variant={typeFilter === "new" ? "default" : "outline"}
              size="sm"
              onClick={() => setTypeFilter("new")}
              className="rounded-full"
            >
              New build
            </Button>
            <Button
              variant={typeFilter === "all" ? "default" : "outline"}
              size="sm"
              onClick={() => setTypeFilter("all")}
              className="rounded-full bg-red-800 hover:bg-red-700 text-white"
            >
              All
            </Button>
          </div>
          <div className="flex gap-2">
            <span className="text-sm text-gray-600">Status</span>
            <Button
              variant={statusFilter === "complete" ? "default" : "outline"}
              size="sm"
              onClick={() => setStatusFilter("complete")}
              className="rounded-full bg-red-800 hover:bg-red-700 text-white"
            >
              Complete
            </Button>
            <Button
              variant={statusFilter === "estimate" ? "default" : "outline"}
              size="sm"
              onClick={() => setStatusFilter("estimate")}
              className="rounded-full"
            >
              Estimate
            </Button>
          </div>
        </div>
      </div>

      <Card className="bg-white">
        <CardContent className="p-6">
          <canvas
            ref={canvasRef}
            className="w-full h-96 cursor-pointer"
            onMouseMove={handleCanvasMouseMove}
            onMouseLeave={() => setHoveredBar(null)}
          />

          {/* Tooltip */}
          {hoveredBar !== null && (
            <div className="mt-4 p-3 bg-gray-100 rounded-lg">
              <h4 className="font-semibold text-gray-900">{filteredData[hoveredBar].name}</h4>
              <p className="text-sm text-gray-600">Embodied Carbon: {filteredData[hoveredBar].value} kgCO₂e/m²</p>
              <p className="text-sm text-gray-600">
                Type: {filteredData[hoveredBar].type === "refurbishment" ? "Refurbishment" : "New Build"}
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
