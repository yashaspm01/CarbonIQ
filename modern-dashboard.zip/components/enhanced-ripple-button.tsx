// components/enhanced-ripple-button.tsx
//
// Wrapper kept for backward-compatibility.
// It re-exports the carbon-aware button so that any
// `import { EnhancedRippleButton } …` continues to work.

export { EnhancedCarbonButton as EnhancedRippleButton } from "@/components/enhanced-carbon-button"
