"use client"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { X, CheckCircle, ArrowRight } from "lucide-react"

interface ServiceDetail {
  id: string
  title: string
  description: string
  fullDescription: string
  benefits: string[]
  features: string[]
  caseStudy: {
    title: string
    description: string
    results: string[]
  }
  pricing: {
    starter: string
    professional: string
    enterprise: string
  }
}

const serviceDetails: Record<string, ServiceDetail> = {
  carbon: {
    id: "carbon",
    title: "Carbon Footprint Analysis",
    description: "Comprehensive assessment of embodied carbon across your entire building portfolio",
    fullDescription:
      "Our AI-powered carbon footprint analysis provides deep insights into the embodied carbon of your building materials, construction processes, and operational systems. Using advanced machine learning algorithms, we analyze thousands of data points to give you actionable recommendations for carbon reduction.",
    benefits: [
      "Reduce embodied carbon by up to 40%",
      "Meet sustainability targets faster",
      "Improve ESG reporting accuracy",
      "Lower construction costs through optimization",
    ],
    features: [
      "Material Impact Assessment",
      "Lifecycle Carbon Analysis",
      "Benchmarking Tools",
      "Real-time Monitoring",
      "Predictive Modeling",
      "Compliance Reporting",
    ],
    caseStudy: {
      title: "GreenTech Tower - 35% Carbon Reduction",
      description:
        "A 40-story commercial building achieved 35% embodied carbon reduction through our analysis and recommendations.",
      results: ["35% carbon reduction", "£2.3M cost savings", "LEED Platinum certification", "18 months ROI"],
    },
    pricing: {
      starter: "£2,500/month",
      professional: "£7,500/month",
      enterprise: "Custom pricing",
    },
  },
  energy: {
    id: "energy",
    title: "Energy Optimization",
    description: "Advanced algorithms to optimize energy consumption and reduce operational carbon",
    fullDescription:
      "Transform your building's energy performance with our intelligent optimization platform. Our system continuously monitors, analyzes, and optimizes energy usage patterns to minimize both operational costs and carbon emissions.",
    benefits: [
      "Reduce energy consumption by 30-50%",
      "Lower operational costs significantly",
      "Improve building performance ratings",
      "Enhance occupant comfort",
    ],
    features: [
      "Smart Energy Monitoring",
      "Predictive Analytics",
      "Performance Optimization",
      "Automated Controls",
      "Weather Integration",
      "Demand Response",
    ],
    caseStudy: {
      title: "EcoOffice Complex - 42% Energy Savings",
      description: "A mixed-use development achieved 42% energy savings through our intelligent optimization system.",
      results: ["42% energy reduction", "£850K annual savings", "Carbon neutral operations", "12 months payback"],
    },
    pricing: {
      starter: "£1,800/month",
      professional: "£5,200/month",
      enterprise: "Custom pricing",
    },
  },
  targets: {
    id: "targets",
    title: "Sustainability Targets",
    description: "Set and track ambitious sustainability goals with comprehensive target management",
    fullDescription:
      "Our sustainability target management system helps organizations set science-based targets, track progress, and achieve net-zero goals. With integrated reporting and compliance features, stay ahead of regulatory requirements.",
    benefits: [
      "Achieve net-zero targets faster",
      "Improve stakeholder confidence",
      "Meet regulatory requirements",
      "Access green financing opportunities",
    ],
    features: [
      "Science-Based Target Setting",
      "Progress Tracking Dashboard",
      "Compliance Reporting",
      "Stakeholder Communication",
      "Risk Assessment",
      "Action Planning",
    ],
    caseStudy: {
      title: "Sustainable Developments Ltd - Net Zero by 2030",
      description: "A property developer set and is successfully tracking towards net-zero emissions by 2030.",
      results: ["Net-zero roadmap", "25% early progress", "£5M green financing", "Industry recognition"],
    },
    pricing: {
      starter: "£3,200/month",
      professional: "£8,900/month",
      enterprise: "Custom pricing",
    },
  },
  certification: {
    id: "certification",
    title: "Green Building Certification",
    description: "Navigate complex certification processes with expert guidance and automated documentation",
    fullDescription:
      "Streamline your green building certification journey with our comprehensive platform. From LEED and BREEAM to local green building standards, we provide the tools and expertise to achieve your certification goals efficiently.",
    benefits: [
      "Faster certification process",
      "Higher certification levels",
      "Reduced documentation burden",
      "Expert guidance throughout",
    ],
    features: [
      "LEED Support",
      "BREEAM Compliance",
      "Automated Documentation",
      "Credit Optimization",
      "Submission Management",
      "Expert Consultation",
    ],
    caseStudy: {
      title: "Marina Bay Residences - LEED Platinum",
      description: "A luxury residential development achieved LEED Platinum certification 6 months ahead of schedule.",
      results: ["LEED Platinum achieved", "6 months early completion", "15% premium value", "Award recognition"],
    },
    pricing: {
      starter: "£4,500/month",
      professional: "£12,000/month",
      enterprise: "Custom pricing",
    },
  },
}

interface ServiceDetailModalProps {
  serviceId: string | null
  isOpen: boolean
  onClose: () => void
}

export function ServiceDetailModal({ serviceId, isOpen, onClose }: ServiceDetailModalProps) {
  const service = serviceId ? serviceDetails[serviceId] : null

  if (!service) return null

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto bg-white dark:bg-gray-900">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-gray-900 dark:text-white">{service.title}</DialogTitle>
          <button
            onClick={onClose}
            className="absolute right-4 top-4 p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-full"
          >
            <X className="w-5 h-5" />
          </button>
        </DialogHeader>

        <div className="space-y-8">
          {/* Overview */}
          <div>
            <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">Overview</h3>
            <p className="text-gray-600 dark:text-gray-300 leading-relaxed">{service.fullDescription}</p>
          </div>

          {/* Benefits */}
          <div>
            <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">Key Benefits</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {service.benefits.map((benefit, index) => (
                <div key={index} className="flex items-center space-x-3">
                  <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0" />
                  <span className="text-gray-600 dark:text-gray-300">{benefit}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Features */}
          <div>
            <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">Features</h3>
            <div className="flex flex-wrap gap-2">
              {service.features.map((feature, index) => (
                <Badge
                  key={index}
                  variant="secondary"
                  className="bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200"
                >
                  {feature}
                </Badge>
              ))}
            </div>
          </div>

          {/* Case Study */}
          <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-6">
            <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">Case Study</h3>
            <h4 className="text-lg font-medium text-gray-800 dark:text-gray-200 mb-2">{service.caseStudy.title}</h4>
            <p className="text-gray-600 dark:text-gray-300 mb-4">{service.caseStudy.description}</p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {service.caseStudy.results.map((result, index) => (
                <div key={index} className="text-center">
                  <div className="text-lg font-semibold text-green-600 dark:text-green-400">{result}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Pricing */}
          <div>
            <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">Pricing</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="border border-gray-200 dark:border-gray-700 rounded-lg p-4 text-center">
                <h4 className="font-semibold text-gray-900 dark:text-white">Starter</h4>
                <p className="text-2xl font-bold text-green-600 dark:text-green-400 my-2">{service.pricing.starter}</p>
                <p className="text-sm text-gray-600 dark:text-gray-400">Perfect for small projects</p>
              </div>
              <div className="border-2 border-green-500 rounded-lg p-4 text-center relative">
                <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                  <Badge className="bg-green-500 text-white">Most Popular</Badge>
                </div>
                <h4 className="font-semibold text-gray-900 dark:text-white">Professional</h4>
                <p className="text-2xl font-bold text-green-600 dark:text-green-400 my-2">
                  {service.pricing.professional}
                </p>
                <p className="text-sm text-gray-600 dark:text-gray-400">For growing portfolios</p>
              </div>
              <div className="border border-gray-200 dark:border-gray-700 rounded-lg p-4 text-center">
                <h4 className="font-semibold text-gray-900 dark:text-white">Enterprise</h4>
                <p className="text-2xl font-bold text-green-600 dark:text-green-400 my-2">
                  {service.pricing.enterprise}
                </p>
                <p className="text-sm text-gray-600 dark:text-gray-400">Large-scale solutions</p>
              </div>
            </div>
          </div>

          {/* CTA */}
          <div className="flex flex-col sm:flex-row gap-4 pt-4">
            <Button className="flex-1 bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600">
              Get Started
              <ArrowRight className="ml-2 w-4 h-4" />
            </Button>
            <Button variant="outline" className="flex-1">
              Schedule Demo
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
