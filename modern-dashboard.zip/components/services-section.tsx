"use client"

import { useEffect, useRef, useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { EnhancedCarbonButton } from "./enhanced-carbon-button"
import { ServiceDetailModal } from "./service-detail-modal"
import { CarbonRippleEffect } from "./carbon-ripple-effect"
import { BarChart3, Zap, Leaf, Target, ArrowRight } from "lucide-react"

const services = [
  {
    id: "carbon",
    icon: BarChart3,
    title: "Carbon Footprint Analysis",
    description:
      "Comprehensive assessment of embodied carbon across your entire building portfolio with AI-powered insights.",
    features: ["Material Impact Assessment", "Lifecycle Analysis", "Benchmarking Tools"],
  },
  {
    id: "energy",
    icon: Zap,
    title: "Energy Optimization",
    description: "Advanced algorithms to optimize energy consumption and reduce operational carbon emissions.",
    features: ["Smart Energy Monitoring", "Predictive Analytics", "Performance Optimization"],
  },
  {
    id: "targets",
    icon: Target,
    title: "Sustainability Targets",
    description: "Set and track ambitious sustainability goals with our comprehensive target management system.",
    features: ["Goal Setting Framework", "Progress Tracking", "Compliance Reporting"],
  },
  {
    id: "certification",
    icon: Leaf,
    title: "Green Building Certification",
    description: "Navigate complex certification processes with our expert guidance and automated documentation.",
    features: ["LEED Support", "BREEAM Compliance", "Automated Reporting"],
  },
]

export function ServicesSection() {
  const [visibleCards, setVisibleCards] = useState<number[]>([])
  const [selectedService, setSelectedService] = useState<string | null>(null)
  const [isModalOpen, setIsModalOpen] = useState(false)
  const sectionRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const cardIndex = Number.parseInt(entry.target.getAttribute("data-index") || "0")
            setVisibleCards((prev) => [...prev, cardIndex])
          }
        })
      },
      { threshold: 0.3 },
    )

    const cards = sectionRef.current?.querySelectorAll("[data-index]")
    cards?.forEach((card) => observer.observe(card))

    return () => observer.disconnect()
  }, [])

  const handleServiceClick = (serviceId: string) => {
    setSelectedService(serviceId)
    setIsModalOpen(true)
  }

  return (
    <>
      <CarbonRippleEffect
        className="py-12 md:py-20 bg-gray-50 dark:bg-gray-900"
        emissionType="low"
        showMolecules={true}
        intensity={1.2}
      >
        <section id="services" ref={sectionRef}>
          <div className="container mx-auto px-4 relative z-10">
            <div className="text-center mb-12 md:mb-16">
              <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-gray-900 dark:text-white mb-4">
                Our Services
              </h2>
              <p className="text-lg md:text-xl text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
                Comprehensive solutions for sustainable building management and carbon reduction
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8 max-w-6xl mx-auto">
              {services.map((service, index) => {
                const Icon = service.icon
                const isVisible = visibleCards.includes(index)

                return (
                  <Card
                    key={index}
                    data-index={index}
                    className={`group hover:shadow-xl transition-all duration-500 border-0 bg-white dark:bg-gray-800 cursor-pointer ${
                      isVisible ? "animate-in slide-in-from-bottom-4" : "opacity-0"
                    }`}
                    onClick={() => handleServiceClick(service.id)}
                  >
                    <CardContent className="p-6 md:p-8">
                      <div className="flex items-start space-x-4">
                        <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-blue-500 rounded-lg flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform">
                          <Icon className="w-6 h-6 text-white" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <h3 className="text-lg md:text-xl font-semibold text-gray-900 dark:text-white mb-3">
                            {service.title}
                          </h3>
                          <p className="text-sm md:text-base text-gray-600 dark:text-gray-300 mb-4 leading-relaxed">
                            {service.description}
                          </p>
                          <ul className="space-y-2 mb-6">
                            {service.features.map((feature, featureIndex) => (
                              <li
                                key={featureIndex}
                                className="flex items-center text-xs md:text-sm text-gray-600 dark:text-gray-400"
                              >
                                <div className="w-1.5 h-1.5 bg-green-500 rounded-full mr-3 flex-shrink-0" />
                                <span className="truncate">{feature}</span>
                              </li>
                            ))}
                          </ul>
                          <EnhancedCarbonButton className="w-full sm:w-auto bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600">
                            Learn More
                            <ArrowRight className="ml-2 w-4 h-4" />
                          </EnhancedCarbonButton>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )
              })}
            </div>
          </div>
        </section>
      </CarbonRippleEffect>

      <ServiceDetailModal serviceId={selectedService} isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
    </>
  )
}
