"use client"

import { useEffect, useRef } from "react"

interface PortfolioImageProps {
  type: "office" | "residential" | "retail" | "industrial"
  name: string
  width?: number
  height?: number
  carbonReduction?: number
}

export function PortfolioImageGenerator({
  type,
  name,
  width = 300,
  height = 200,
  carbonReduction = 0,
}: PortfolioImageProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    canvas.width = width
    canvas.height = height

    // Clear canvas
    ctx.clearRect(0, 0, width, height)

    // Create gradient background based on building type
    const gradient = ctx.createLinearGradient(0, 0, width, height)

    switch (type) {
      case "office":
        gradient.addColorStop(0, "#1e40af") // Blue
        gradient.addColorStop(1, "#3b82f6")
        break
      case "residential":
        gradient.addColorStop(0, "#059669") // Green
        gradient.addColorStop(1, "#10b981")
        break
      case "retail":
        gradient.addColorStop(0, "#dc2626") // Red
        gradient.addColorStop(1, "#ef4444")
        break
      case "industrial":
        gradient.addColorStop(0, "#4b5563") // Gray
        gradient.addColorStop(1, "#6b7280")
        break
    }

    ctx.fillStyle = gradient
    ctx.fillRect(0, 0, width, height)

    // Draw building silhouette
    ctx.fillStyle = "rgba(255, 255, 255, 0.2)"

    if (type === "office") {
      // Draw office building
      ctx.fillRect(width * 0.2, height * 0.3, width * 0.6, height * 0.7)
      ctx.fillRect(width * 0.3, height * 0.1, width * 0.4, height * 0.2)

      // Windows
      ctx.fillStyle = "rgba(255, 255, 255, 0.4)"
      for (let i = 0; i < 6; i++) {
        for (let j = 0; j < 4; j++) {
          ctx.fillRect(
            width * 0.25 + i * (width * 0.08),
            height * 0.35 + j * (height * 0.12),
            width * 0.05,
            height * 0.08,
          )
        }
      }
    } else if (type === "residential") {
      // Draw residential building
      ctx.fillRect(width * 0.15, height * 0.4, width * 0.7, height * 0.6)

      // Roof
      ctx.beginPath()
      ctx.moveTo(width * 0.1, height * 0.4)
      ctx.lineTo(width * 0.5, height * 0.2)
      ctx.lineTo(width * 0.9, height * 0.4)
      ctx.closePath()
      ctx.fill()

      // Windows
      ctx.fillStyle = "rgba(255, 255, 255, 0.4)"
      ctx.fillRect(width * 0.25, height * 0.5, width * 0.15, height * 0.2)
      ctx.fillRect(width * 0.6, height * 0.5, width * 0.15, height * 0.2)

      // Door
      ctx.fillRect(width * 0.45, height * 0.6, width * 0.1, height * 0.4)
    } else if (type === "retail") {
      // Draw retail building
      ctx.fillRect(width * 0.1, height * 0.4, width * 0.8, height * 0.6)

      // Large windows
      ctx.fillStyle = "rgba(255, 255, 255, 0.4)"
      ctx.fillRect(width * 0.15, height * 0.45, width * 0.7, height * 0.3)

      // Entrance
      ctx.fillRect(width * 0.4, height * 0.8, width * 0.2, height * 0.2)
    } else if (type === "industrial") {
      // Draw industrial building
      ctx.fillRect(width * 0.1, height * 0.5, width * 0.8, height * 0.5)

      // Chimney
      ctx.fillRect(width * 0.7, height * 0.2, width * 0.1, height * 0.3)

      // Large doors
      ctx.fillStyle = "rgba(255, 255, 255, 0.4)"
      ctx.fillRect(width * 0.2, height * 0.6, width * 0.2, height * 0.4)
      ctx.fillRect(width * 0.6, height * 0.6, width * 0.2, height * 0.4)
    }

    // Add carbon reduction indicator
    if (carbonReduction > 0) {
      ctx.fillStyle = "rgba(34, 197, 94, 0.9)"
      ctx.fillRect(width - 80, 10, 70, 25)

      ctx.fillStyle = "white"
      ctx.font = "12px Inter, sans-serif"
      ctx.textAlign = "center"
      ctx.fillText(`-${carbonReduction}% CO₂`, width - 45, 27)
    }

    // Add building name
    ctx.fillStyle = "rgba(0, 0, 0, 0.7)"
    ctx.fillRect(0, height - 40, width, 40)

    ctx.fillStyle = "white"
    ctx.font = "16px Inter, sans-serif"
    ctx.textAlign = "center"
    ctx.fillText(name, width / 2, height - 15)

    // Add sustainability elements
    ctx.fillStyle = "rgba(34, 197, 94, 0.6)"
    for (let i = 0; i < 5; i++) {
      ctx.beginPath()
      ctx.arc(20 + i * 15, height - 60, 3, 0, Math.PI * 2)
      ctx.fill()
    }
  }, [type, name, width, height, carbonReduction])

  return <canvas ref={canvasRef} className="rounded-lg shadow-lg" style={{ maxWidth: "100%", height: "auto" }} />
}
