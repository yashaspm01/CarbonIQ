"use client"

import { useEffect, useState } from "react"

export function Loader({ onComplete }: { onComplete: () => void }) {
  const [progress, setProgress] = useState(0)

  useEffect(() => {
    const timer = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(timer)
          setTimeout(onComplete, 800)
          return 100
        }
        return prev + 1.5
      })
    }, 60)

    return () => clearInterval(timer)
  }, [onComplete])

  return (
    <div className="fixed inset-0 z-50 bg-black dark:bg-gray-950 flex items-center justify-center transition-colors duration-300">
      <div className="relative w-full max-w-lg px-8">
        {/* Main Loader Video */}
        <div className="relative w-64 h-64 mx-auto mb-8">
          <video
            autoPlay
            loop
            muted
            playsInline
            className="w-full h-full object-cover rounded-full"
            crossOrigin="anonymous"
          >
            <source src="/videos/loader.mp4" type="video/mp4" />
          </video>

          {/* Progress Ring Overlay */}
          <div className="absolute inset-0 flex items-center justify-center">
            <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
              <circle
                cx="50"
                cy="50"
                r="45"
                stroke="rgba(255,255,255,0.1)"
                strokeWidth="2"
                fill="none"
                className="drop-shadow-lg"
              />
              <circle
                cx="50"
                cy="50"
                r="45"
                stroke="url(#progressGradient)"
                strokeWidth="3"
                fill="none"
                strokeLinecap="round"
                strokeDasharray={`${2 * Math.PI * 45}`}
                strokeDashoffset={`${2 * Math.PI * 45 * (1 - progress / 100)}`}
                className="transition-all duration-300 ease-out drop-shadow-lg"
              />
              <defs>
                <linearGradient id="progressGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#10B981" />
                  <stop offset="50%" stopColor="#3B82F6" />
                  <stop offset="100%" stopColor="#8B5CF6" />
                </linearGradient>
              </defs>
            </svg>

            {/* Progress Text */}
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center">
                <span className="text-white text-2xl font-light">{Math.round(progress)}%</span>
              </div>
            </div>
          </div>
        </div>

        {/* Loading Text with Animation */}
        <div className="text-center">
          <h2 className="text-white dark:text-gray-100 text-3xl font-light mb-4 animate-pulse">CarbonIQ</h2>
          <p className="text-gray-400 dark:text-gray-500 text-lg mb-4">Loading Carbon Intelligence Platform...</p>

          {/* Loading Steps */}
          <div className="space-y-2 text-sm text-gray-500">
            <div className={`transition-opacity duration-500 ${progress > 20 ? "opacity-100" : "opacity-50"}`}>
              ✓ Initializing AI Analytics Engine
            </div>
            <div className={`transition-opacity duration-500 ${progress > 40 ? "opacity-100" : "opacity-50"}`}>
              ✓ Loading Carbon Footprint Database
            </div>
            <div className={`transition-opacity duration-500 ${progress > 60 ? "opacity-100" : "opacity-50"}`}>
              ✓ Preparing Sustainability Metrics
            </div>
            <div className={`transition-opacity duration-500 ${progress > 80 ? "opacity-100" : "opacity-50"}`}>
              ✓ Optimizing User Experience
            </div>
            <div className={`transition-opacity duration-500 ${progress > 95 ? "opacity-100" : "opacity-50"}`}>
              ✓ Ready to Transform Your Portfolio
            </div>
          </div>
        </div>

        {/* Animated Dots */}
        <div className="flex justify-center mt-8 space-x-2">
          {[0, 1, 2].map((i) => (
            <div
              key={i}
              className="w-3 h-3 bg-green-500 rounded-full animate-bounce"
              style={{ animationDelay: `${i * 0.2}s` }}
            />
          ))}
        </div>
      </div>
    </div>
  )
}
