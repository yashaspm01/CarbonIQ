"use client"

import type React from "react"

import { useEffect, useRef } from "react"

interface RippleEffectBackgroundProps {
  children: React.ReactNode
  className?: string
}

export function RippleEffectBackground({ children, className = "" }: RippleEffectBackgroundProps) {
  const containerRef = useRef<HTMLDivElement>(null)
  const videoRef = useRef<HTMLVideoElement>(null)

  useEffect(() => {
    const container = containerRef.current
    if (!container) return

    const createRipple = (e: MouseEvent) => {
      const ripple = document.createElement("div")
      const rect = container.getBoundingClientRect()
      const x = e.clientX - rect.left
      const y = e.clientY - rect.top

      ripple.style.position = "absolute"
      ripple.style.left = `${x}px`
      ripple.style.top = `${y}px`
      ripple.style.width = "0"
      ripple.style.height = "0"
      ripple.style.borderRadius = "50%"
      ripple.style.background = "rgba(34, 197, 94, 0.3)"
      ripple.style.transform = "translate(-50%, -50%)"
      ripple.style.animation = "ripple-expand 0.8s ease-out forwards"
      ripple.style.pointerEvents = "none"
      ripple.style.zIndex = "1"

      container.appendChild(ripple)

      setTimeout(() => {
        if (container.contains(ripple)) {
          container.removeChild(ripple)
        }
      }, 800)
    }

    container.addEventListener("click", createRipple)

    return () => {
      container.removeEventListener("click", createRipple)
    }
  }, [])

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting && videoRef.current) {
            videoRef.current.play()
          }
        })
      },
      { threshold: 0.3 },
    )

    if (videoRef.current) {
      observer.observe(videoRef.current)
    }

    return () => observer.disconnect()
  }, [])

  return (
    <div ref={containerRef} className={`relative overflow-hidden ${className}`}>
      {/* Background Ripple Video */}
      <div className="absolute inset-0 opacity-10 pointer-events-none">
        <video ref={videoRef} loop muted playsInline className="w-full h-full object-cover" crossOrigin="anonymous">
          <source src="/videos/ripple-effect.mp4" type="video/mp4" />
        </video>
      </div>
      {children}
    </div>
  )
}
