"use client"

import type React from "react"

import { useEffect, useState, useRef } from "react"
import { Leaf, BarChart3, Zap, Target } from "lucide-react"

interface LoadingStep {
  id: string
  title: string
  description: string
  icon: React.ComponentType<{ className?: string }>
  progress: number
}

const loadingSteps: LoadingStep[] = [
  {
    id: "init",
    title: "Initializing AI Analytics Engine",
    description: "Starting carbon intelligence systems...",
    icon: BarChart3,
    progress: 15,
  },
  {
    id: "database",
    title: "Loading Carbon Footprint Database",
    description: "Accessing global emissions data...",
    icon: Leaf,
    progress: 35,
  },
  {
    id: "metrics",
    title: "Preparing Sustainability Metrics",
    description: "Calculating environmental impact...",
    icon: Target,
    progress: 55,
  },
  {
    id: "optimization",
    title: "Optimizing Energy Models",
    description: "Calibrating efficiency algorithms...",
    icon: Zap,
    progress: 75,
  },
  {
    id: "ready",
    title: "Platform Ready",
    description: "Welcome to CarbonIQ Intelligence",
    icon: Leaf,
    progress: 100,
  },
]

export function SophisticatedLoader({ onComplete }: { onComplete: () => void }) {
  const [progress, setProgress] = useState(0)
  const [currentStep, setCurrentStep] = useState(0)
  const [isCompleting, setIsCompleting] = useState(false)
  const [particles, setParticles] = useState<Array<{ id: number; x: number; y: number; delay: number }>>([])
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)

  // Generate floating particles
  useEffect(() => {
    const newParticles = Array.from({ length: 20 }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      y: Math.random() * 100,
      delay: Math.random() * 2,
    }))
    setParticles(newParticles)
  }, [])

  // Animated canvas background
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    canvas.width = window.innerWidth
    canvas.height = window.innerHeight

    const drawWave = (time: number) => {
      ctx.clearRect(0, 0, canvas.width, canvas.height)

      // Create gradient
      const gradient = ctx.createLinearGradient(0, 0, canvas.width, canvas.height)
      gradient.addColorStop(0, "rgba(16, 185, 129, 0.1)")
      gradient.addColorStop(0.5, "rgba(59, 130, 246, 0.1)")
      gradient.addColorStop(1, "rgba(139, 92, 246, 0.1)")

      // Draw animated waves
      ctx.fillStyle = gradient
      ctx.beginPath()
      ctx.moveTo(0, canvas.height)

      for (let x = 0; x <= canvas.width; x += 10) {
        const y = canvas.height / 2 + Math.sin((x + time) * 0.01) * 50 + Math.sin((x + time) * 0.02) * 30
        ctx.lineTo(x, y)
      }

      ctx.lineTo(canvas.width, canvas.height)
      ctx.closePath()
      ctx.fill()
    }

    let animationId: number
    const animate = (time: number) => {
      drawWave(time)
      animationId = requestAnimationFrame(animate)
    }

    animate(0)

    return () => {
      if (animationId) {
        cancelAnimationFrame(animationId)
      }
    }
  }, [])

  // Progress animation - REMOVED POP-UP EFFECT
  useEffect(() => {
    const timer = setInterval(() => {
      setProgress((prev) => {
        const newProgress = prev + 0.8

        // Update current step based on progress - smooth transition
        const stepIndex = loadingSteps.findIndex((step) => newProgress <= step.progress)
        if (stepIndex !== -1 && stepIndex !== currentStep) {
          setCurrentStep(stepIndex)
        }

        if (newProgress >= 100) {
          clearInterval(timer)
          setIsCompleting(true)
          // Smooth completion without pop-up
          setTimeout(() => {
            onComplete()
          }, 1500)
          return 100
        }
        return newProgress
      })
    }, 80)

    return () => clearInterval(timer)
  }, [onComplete, currentStep])

  const currentStepData = loadingSteps[currentStep]

  return (
    <div className="fixed inset-0 z-50 bg-gradient-to-br from-gray-900 via-black to-gray-900 overflow-hidden">
      {/* Animated Canvas Background */}
      <canvas ref={canvasRef} className="absolute inset-0 opacity-30" />

      {/* Floating Particles */}
      <div className="absolute inset-0">
        {particles.map((particle) => (
          <div
            key={particle.id}
            className="absolute w-2 h-2 bg-green-400 rounded-full opacity-60 animate-pulse"
            style={{
              left: `${particle.x}%`,
              top: `${particle.y}%`,
              animationDelay: `${particle.delay}s`,
              animationDuration: "3s",
            }}
          />
        ))}
      </div>

      {/* Main Content */}
      <div className="relative z-10 flex items-center justify-center min-h-screen p-8">
        <div className="w-full max-w-2xl text-center">
          {/* Logo Animation */}
          <div className="mb-12">
            <div className="relative inline-block">
              <div className="w-24 h-24 mx-auto mb-6 relative">
                {/* Rotating rings */}
                <div className="absolute inset-0 border-4 border-green-500/30 rounded-full animate-spin" />
                <div
                  className="absolute inset-2 border-4 border-blue-500/30 rounded-full animate-spin"
                  style={{ animationDirection: "reverse", animationDuration: "3s" }}
                />
                <div
                  className="absolute inset-4 border-4 border-purple-500/30 rounded-full animate-spin"
                  style={{ animationDuration: "4s" }}
                />

                {/* Center logo */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-blue-500 rounded-full flex items-center justify-center animate-pulse">
                    <Leaf className="w-6 h-6 text-white" />
                  </div>
                </div>
              </div>

              <h1 className="text-4xl font-bold text-white mb-2 animate-fade-in">CarbonIQ</h1>
              <p className="text-green-400 text-lg animate-fade-in-delay">Carbon Intelligence Platform</p>
            </div>
          </div>

          {/* Main Loader Video */}
          <div className="relative w-80 h-80 mx-auto mb-12">
            <video
              ref={videoRef}
              autoPlay
              loop
              muted
              playsInline
              className="w-full h-full object-cover rounded-full shadow-2xl"
              crossOrigin="anonymous"
            >
              <source src="/videos/loader.mp4" type="video/mp4" />
            </video>

            {/* Progress Ring with Glow Effect */}
            <div className="absolute inset-0 flex items-center justify-center">
              <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                {/* Background ring */}
                <circle
                  cx="50"
                  cy="50"
                  r="45"
                  stroke="rgba(255,255,255,0.1)"
                  strokeWidth="2"
                  fill="none"
                  className="drop-shadow-lg"
                />

                {/* Progress ring with glow */}
                <circle
                  cx="50"
                  cy="50"
                  r="45"
                  stroke="url(#glowGradient)"
                  strokeWidth="3"
                  fill="none"
                  strokeLinecap="round"
                  strokeDasharray={`${2 * Math.PI * 45}`}
                  strokeDashoffset={`${2 * Math.PI * 45 * (1 - progress / 100)}`}
                  className="transition-all duration-500 ease-out"
                  style={{
                    filter: "drop-shadow(0 0 10px rgba(16, 185, 129, 0.8))",
                  }}
                />

                <defs>
                  <linearGradient id="glowGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stopColor="#10B981" />
                    <stop offset="33%" stopColor="#3B82F6" />
                    <stop offset="66%" stopColor="#8B5CF6" />
                    <stop offset="100%" stopColor="#EC4899" />
                  </linearGradient>
                </defs>
              </svg>

              {/* Progress Text with Animation */}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center">
                  <div className="text-3xl font-bold text-white mb-2 animate-pulse">{Math.round(progress)}%</div>
                  <div className="text-sm text-green-400">Loading...</div>
                </div>
              </div>
            </div>
          </div>

          {/* Current Step Display - Smooth transitions */}
          <div className="mb-8 transition-all duration-500 ease-in-out">
            <div className="flex items-center justify-center mb-4">
              <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-blue-500 rounded-full flex items-center justify-center mr-4 transition-all duration-300">
                <currentStepData.icon className="w-6 h-6 text-white" />
              </div>
              <div className="text-left">
                <h3 className="text-xl font-semibold text-white transition-all duration-300">
                  {currentStepData.title}
                </h3>
                <p className="text-gray-400 transition-all duration-300">{currentStepData.description}</p>
              </div>
            </div>

            {/* Progress Bar */}
            <div className="w-full bg-gray-800 rounded-full h-2 mb-4 overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-green-500 via-blue-500 to-purple-500 rounded-full transition-all duration-500 ease-out relative"
                style={{ width: `${progress}%` }}
              >
                <div className="absolute inset-0 bg-white/20 animate-pulse" />
              </div>
            </div>
          </div>

          {/* Loading Steps Timeline */}
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-8">
            {loadingSteps.map((step, index) => {
              const isActive = index === currentStep
              const isCompleted = progress > step.progress
              const StepIcon = step.icon

              return (
                <div
                  key={step.id}
                  className={`flex flex-col items-center p-4 rounded-lg transition-all duration-500 ${
                    isActive
                      ? "bg-gradient-to-r from-green-500/20 to-blue-500/20 scale-105"
                      : isCompleted
                        ? "bg-green-500/10"
                        : "bg-gray-800/50"
                  }`}
                >
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center mb-2 transition-all duration-500 ${
                      isActive
                        ? "bg-gradient-to-r from-green-500 to-blue-500 animate-pulse"
                        : isCompleted
                          ? "bg-green-500"
                          : "bg-gray-600"
                    }`}
                  >
                    <StepIcon className="w-4 h-4 text-white" />
                  </div>
                  <div className="text-xs text-center">
                    <div className={`font-medium ${isActive ? "text-white" : "text-gray-400"}`}>
                      {step.title.split(" ").slice(0, 2).join(" ")}
                    </div>
                  </div>
                </div>
              )
            })}
          </div>

          {/* Smooth Completion Animation - NO POP-UP */}
          {isCompleting && (
            <div className="absolute inset-0 flex items-center justify-center bg-black/60 transition-all duration-1000 ease-in-out">
              <div className="text-center">
                <div className="w-32 h-32 mx-auto mb-8 relative">
                  <div className="absolute inset-0 border-4 border-green-500 rounded-full animate-spin opacity-60" />
                  <div
                    className="absolute inset-4 border-4 border-blue-500 rounded-full animate-spin opacity-40"
                    style={{ animationDirection: "reverse" }}
                  />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Leaf className="w-16 h-16 text-green-500 animate-pulse" />
                  </div>
                </div>
                <h2 className="text-3xl font-bold text-white mb-4 transition-all duration-500">Welcome to CarbonIQ!</h2>
                <p className="text-green-400 text-lg transition-all duration-500">
                  Initializing your carbon intelligence platform...
                </p>
              </div>
            </div>
          )}

          {/* Animated Dots */}
          <div className="flex justify-center space-x-2">
            {[0, 1, 2, 3, 4].map((i) => (
              <div
                key={i}
                className="w-2 h-2 bg-gradient-to-r from-green-500 to-blue-500 rounded-full animate-bounce"
                style={{ animationDelay: `${i * 0.2}s` }}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
