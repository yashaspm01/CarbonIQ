"use client"

import type React from "react"
import { useEffect, useRef, useState } from "react"

interface CarbonRipple {
  id: number
  x: number
  y: number
  timestamp: number
  type: "emission" | "reduction" | "neutral"
  intensity: number
}

interface CarbonRippleEffectProps {
  children: React.ReactNode
  className?: string
  emissionType?: "high" | "medium" | "low" | "negative"
  showMolecules?: boolean
  intensity?: number
}

export function CarbonRippleEffect({
  children,
  className = "",
  emissionType = "medium",
  showMolecules = true,
  intensity = 1,
}: CarbonRippleEffectProps) {
  const containerRef = useRef<HTMLDivElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [ripples, setRipples] = useState<CarbonRipple[]>([])
  const [molecules, setMolecules] = useState<
    Array<{ id: number; x: number; y: number; vx: number; vy: number; life: number }>
  >([])
  const animationRef = useRef<number>()

  // Generate CO₂ molecules
  useEffect(() => {
    if (!showMolecules) return

    const newMolecules = Array.from({ length: 15 }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      y: Math.random() * 100,
      vx: (Math.random() - 0.5) * 0.5,
      vy: (Math.random() - 0.5) * 0.5,
      life: Math.random() * 100,
    }))
    setMolecules(newMolecules)
  }, [showMolecules])

  // Animate molecules
  useEffect(() => {
    if (!showMolecules) return

    const animateMolecules = () => {
      setMolecules((prev) =>
        prev.map((molecule) => ({
          ...molecule,
          x: (molecule.x + molecule.vx + 100) % 100,
          y: (molecule.y + molecule.vy + 100) % 100,
          life: (molecule.life + 1) % 100,
        })),
      )
    }

    const interval = setInterval(animateMolecules, 100)
    return () => clearInterval(interval)
  }, [showMolecules])

  // Canvas animation for advanced ripple effects
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const resizeCanvas = () => {
      const rect = canvas.getBoundingClientRect()
      canvas.width = rect.width
      canvas.height = rect.height
    }

    resizeCanvas()
    window.addEventListener("resize", resizeCanvas)

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height)

      // Draw carbon emission waves
      ripples.forEach((ripple) => {
        const age = Date.now() - ripple.timestamp
        const maxAge = 2000
        const progress = age / maxAge

        if (progress < 1) {
          const radius = progress * 200 * ripple.intensity
          const opacity = (1 - progress) * 0.6

          // Create gradient based on emission type
          const gradient = ctx.createRadialGradient(ripple.x, ripple.y, 0, ripple.x, ripple.y, radius)

          switch (ripple.type) {
            case "emission":
              gradient.addColorStop(0, `rgba(239, 68, 68, ${opacity})`) // Red for high emissions
              gradient.addColorStop(0.5, `rgba(251, 146, 60, ${opacity * 0.7})`) // Orange
              gradient.addColorStop(1, `rgba(254, 202, 202, ${opacity * 0.3})`) // Light red
              break
            case "reduction":
              gradient.addColorStop(0, `rgba(34, 197, 94, ${opacity})`) // Green for reduction
              gradient.addColorStop(0.5, `rgba(74, 222, 128, ${opacity * 0.7})`) // Light green
              gradient.addColorStop(1, `rgba(187, 247, 208, ${opacity * 0.3})`) // Very light green
              break
            case "neutral":
              gradient.addColorStop(0, `rgba(59, 130, 246, ${opacity})`) // Blue for neutral
              gradient.addColorStop(0.5, `rgba(147, 197, 253, ${opacity * 0.7})`) // Light blue
              gradient.addColorStop(1, `rgba(219, 234, 254, ${opacity * 0.3})`) // Very light blue
              break
          }

          ctx.fillStyle = gradient
          ctx.beginPath()
          ctx.arc(ripple.x, ripple.y, radius, 0, Math.PI * 2)
          ctx.fill()

          // Add carbon particle effects
          if (ripple.type === "emission") {
            for (let i = 0; i < 8; i++) {
              const angle = (i / 8) * Math.PI * 2
              const particleRadius = radius * 0.8
              const particleX = ripple.x + Math.cos(angle) * particleRadius
              const particleY = ripple.y + Math.sin(angle) * particleRadius

              ctx.fillStyle = `rgba(239, 68, 68, ${opacity * 0.8})`
              ctx.beginPath()
              ctx.arc(particleX, particleY, 2, 0, Math.PI * 2)
              ctx.fill()
            }
          }

          // Add CO₂ molecule visualization
          if (progress < 0.5) {
            const moleculeOpacity = opacity * 2
            ctx.fillStyle = `rgba(75, 85, 99, ${moleculeOpacity})`

            // Draw CO₂ molecule structure
            const centerX = ripple.x
            const centerY = ripple.y
            const bondLength = 15 * (progress + 0.5)

            // Carbon atom (center)
            ctx.beginPath()
            ctx.arc(centerX, centerY, 4, 0, Math.PI * 2)
            ctx.fill()

            // Oxygen atoms
            ctx.beginPath()
            ctx.arc(centerX - bondLength, centerY, 3, 0, Math.PI * 2)
            ctx.fill()

            ctx.beginPath()
            ctx.arc(centerX + bondLength, centerY, 3, 0, Math.PI * 2)
            ctx.fill()

            // Bonds
            ctx.strokeStyle = `rgba(75, 85, 99, ${moleculeOpacity})`
            ctx.lineWidth = 2
            ctx.beginPath()
            ctx.moveTo(centerX - 4, centerY)
            ctx.lineTo(centerX - bondLength + 3, centerY)
            ctx.moveTo(centerX + 4, centerY)
            ctx.lineTo(centerX + bondLength - 3, centerY)
            ctx.stroke()
          }
        }
      })

      animationRef.current = requestAnimationFrame(animate)
    }

    animate()

    return () => {
      window.removeEventListener("resize", resizeCanvas)
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current)
      }
    }
  }, [ripples])

  const createCarbonRipple = (event: React.MouseEvent) => {
    if (!containerRef.current || !canvasRef.current) return

    const rect = canvasRef.current.getBoundingClientRect()
    const x = event.clientX - rect.left
    const y = event.clientY - rect.top

    // Determine ripple type based on emission type
    let rippleType: "emission" | "reduction" | "neutral"
    switch (emissionType) {
      case "high":
        rippleType = "emission"
        break
      case "negative":
        rippleType = "reduction"
        break
      default:
        rippleType = "neutral"
    }

    const newRipple: CarbonRipple = {
      id: Date.now() + Math.random(),
      x,
      y,
      timestamp: Date.now(),
      type: rippleType,
      intensity: intensity,
    }

    setRipples((prev) => [...prev, newRipple])

    // Clean up old ripples
    setTimeout(() => {
      setRipples((prev) => prev.filter((ripple) => ripple.id !== newRipple.id))
    }, 2000)
  }

  const getEmissionColor = () => {
    switch (emissionType) {
      case "high":
        return "from-red-500/20 to-orange-500/10"
      case "medium":
        return "from-yellow-500/20 to-orange-500/10"
      case "low":
        return "from-green-500/20 to-blue-500/10"
      case "negative":
        return "from-green-600/20 to-emerald-500/10"
      default:
        return "from-blue-500/20 to-purple-500/10"
    }
  }

  return (
    <div ref={containerRef} className={`relative overflow-hidden ${className}`} onClick={createCarbonRipple}>
      {/* Canvas for advanced ripple effects */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 pointer-events-none z-10"
        style={{ width: "100%", height: "100%" }}
      />

      {/* Background gradient based on emission type */}
      <div className={`absolute inset-0 bg-gradient-to-br ${getEmissionColor()} opacity-30 pointer-events-none`} />

      {/* Floating CO₂ molecules */}
      {showMolecules && (
        <div className="absolute inset-0 pointer-events-none">
          {molecules.map((molecule) => (
            <div
              key={molecule.id}
              className="absolute transition-all duration-1000 ease-linear"
              style={{
                left: `${molecule.x}%`,
                top: `${molecule.y}%`,
                opacity: 0.1 + (molecule.life / 100) * 0.3,
                transform: `scale(${0.5 + (molecule.life / 100) * 0.5})`,
              }}
            >
              <div className="relative">
                {/* CO₂ molecule visualization */}
                <div className="flex items-center">
                  {/* Oxygen atom */}
                  <div className="w-2 h-2 bg-red-400 rounded-full" />
                  {/* Bond */}
                  <div className="w-3 h-0.5 bg-gray-400" />
                  {/* Carbon atom */}
                  <div className="w-3 h-3 bg-gray-600 rounded-full" />
                  {/* Bond */}
                  <div className="w-3 h-0.5 bg-gray-400" />
                  {/* Oxygen atom */}
                  <div className="w-2 h-2 bg-red-400 rounded-full" />
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Emission intensity indicator */}
      <div className="absolute top-2 right-2 pointer-events-none z-20">
        <div
          className={`px-2 py-1 rounded-full text-xs font-medium ${
            emissionType === "high"
              ? "bg-red-100 text-red-800"
              : emissionType === "medium"
                ? "bg-yellow-100 text-yellow-800"
                : emissionType === "low"
                  ? "bg-green-100 text-green-800"
                  : "bg-emerald-100 text-emerald-800"
          }`}
        >
          {emissionType === "high"
            ? "High Emissions"
            : emissionType === "medium"
              ? "Medium Emissions"
              : emissionType === "low"
                ? "Low Emissions"
                : "Carbon Negative"}
        </div>
      </div>

      {/* Content */}
      <div className="relative z-10">{children}</div>
    </div>
  )
}
