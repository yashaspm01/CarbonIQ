"use client"

import { useState, useEffect } from "react"
import { ThemeProvider } from "@/contexts/theme-context"
import { SophisticatedLoader } from "@/components/sophisticated-loader"
import { Navigation } from "@/components/navigation"
import { HeroSection } from "@/components/hero-section"
import { ServicesSection } from "@/components/services-section"
import { InteractivePortfolio } from "@/components/interactive-portfolio"
import { AnalyticsSection } from "@/components/analytics-section"
import { TestimonialsSection } from "@/components/testimonials-section"
import { ContactSection } from "@/components/contact-section"
import { Footer } from "@/components/footer"

export default function Home() {
  const [isLoading, setIsLoading] = useState(true)
  const [showContent, setShowContent] = useState(false)

  useEffect(() => {
    // Smooth scroll behavior
    document.documentElement.style.scrollBehavior = "smooth"

    return () => {
      document.documentElement.style.scrollBehavior = "auto"
    }
  }, [])

  const handleLoadingComplete = () => {
    setIsLoading(false)
    // Add a small delay before showing content for smooth transition
    setTimeout(() => {
      setShowContent(true)
    }, 300)
  }

  if (isLoading) {
    return (
      <ThemeProvider>
        <SophisticatedLoader onComplete={handleLoadingComplete} />
      </ThemeProvider>
    )
  }

  return (
    <ThemeProvider>
      <div
        className={`min-h-screen bg-white dark:bg-gray-900 transition-all duration-1000 ${
          showContent ? "opacity-100 transform-none" : "opacity-0 transform scale-95"
        }`}
      >
        <Navigation />
        <HeroSection />
        <ServicesSection />
        <InteractivePortfolio />
        <AnalyticsSection />
        <TestimonialsSection />
        <ContactSection />
        <Footer />
      </div>
    </ThemeProvider>
  )
}
